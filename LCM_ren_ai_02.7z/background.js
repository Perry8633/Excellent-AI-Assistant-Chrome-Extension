chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  switch(request.action) {
    case "saveCSV":
      saveAsCSV(request.data)
        .then(result => sendResponse(result))
        .catch(error => sendResponse({status: "error", message: error.message}));
      return true;
      
    case "getConfig":
      chrome.storage.sync.get('formFields', config => {
        sendResponse({config: config.formFields || []});
      });
      return true;
      
    case "saveConfig":
      chrome.storage.sync.set({formFields: request.config}, () => {
        sendResponse({status: "success"});
      });
      return true;
  }
});

async function saveAsCSV(data) {
  // 生成CSV内容
  const headers = Object.keys(data);
  const values = Object.values(data);
  
  let csvContent = "data:text/csv;charset=utf-8,";
  csvContent += headers.join(",") + "\n";
  
  const escapedValues = values.map(val => {
    // 处理特殊字符和换行
    return `"${val.toString().replace(/"/g, '""').replace(/\n/g, '\\n')}"`;
  });
  
  csvContent += escapedValues.join(",") + "\n";
  
  // 生成文件名
  const fileName = `${data["名称"] || "表单数据"}_${new Date().toISOString().slice(0, 19).replace(/:/g, "-")}.csv`;
  
  // 使用downloads API进行下载 (更稳定的方案)
  try {
    const downloadId = await chrome.downloads.download({
      url: encodeURI(csvContent),
      filename: fileName,
      saveAs: true
    });
    return {status: "success", downloadId};
  } catch (error) {
    // 降级方案：使用blob URL
    const blob = new Blob([csvContent.replace('data:text/csv;charset=utf-8,', '')], {type: 'text/csv;charset=utf-8;'});
    const url = URL.createObjectURL(blob);
    
    try {
      const downloadId = await chrome.downloads.download({
        url: url,
        filename: fileName,
        saveAs: true
      });
      return {status: "success", downloadId, fallback: true};
    } catch (fallbackError) {
      throw new Error("下载失败，不支持的浏览器或权限问题");
    }
  }
}