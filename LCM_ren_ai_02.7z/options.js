document.addEventListener('DOMContentLoaded', () => {
  const fieldsContainer = document.getElementById('fields-container');
  const addFieldBtn = document.getElementById('add-field');
  const saveConfigBtn = document.getElementById('save-config');
  const statusEl = document.getElementById('status');
  const startKeywordInput = document.getElementById('start-keyword');
  const endKeywordInput = document.getElementById('end-keyword');
  
  let fieldIndex = 0;

  const defaultFields = [
    {name: "名称", selectors: ["[id*='name']", "[name*='title']", "[id*='company-name']", "[name*='company-name']"]},
    {name: "类型", selectors: ["[id*='type']", "[name*='type']", "[id*='category']", "[name*='category']"]},
    {name: "受限制主体编号", selectors: ["[id*='number']", "[name*='code']", "[id*='entity-id']", "[name*='entity-id']", "[id*='company-code']"]},
    {name: "国家/地区", selectors: ["[id*='country']", "[name*='region']", "[name*='country_region']"]},
    {name: "城市", selectors: ["[id*='city']", "[name*='city']"]},
    {name: "详细地址", selectors: ["[id*='address']", "[name*='addr']", "[id*='street']"]},
    {name: "邮编", selectors: ["[id*='postcode']", "[name*='zip']", "[id*='postal_code']"]},
    {name: "备注", selectors: ["[id*='remark']", "[name*='note']", "textarea[name*='comment']", "textarea[id*='comment']"]}
    // "扫描主体名称" will be handled by a different mechanism in content.js, not as a standard field here
  ];

  loadConfig();

  addFieldBtn.addEventListener('click', () => createFieldElement());
  saveConfigBtn.addEventListener('click', saveConfig);
  fieldsContainer.addEventListener('click', handleFieldActions);

  function createFieldElement(field = { name: '', selectors: [] }) {
    const fieldItem = document.createElement('div');
    fieldItem.className = 'field-item';
    const currentFieldIndex = fieldIndex++;
    
    fieldItem.innerHTML = `
      <label for="field-name-${currentFieldIndex}">字段名称 / Field Name:</label>
      <input type="text" id="field-name-${currentFieldIndex}" class="field-name" value="${field.name}">
      <label for="field-selectors-${currentFieldIndex}">选择器 (逗号分隔) / Selectors (comma-separated):</label>
      <input type="text" id="field-selectors-${currentFieldIndex}" class="field-selectors" value="${Array.isArray(field.selectors) ? field.selectors.join(',') : ''}">
      <button class="remove-field">删除 / Remove</button>
    `;
    fieldsContainer.appendChild(fieldItem);
  }

  function handleFieldActions(event) {
    if (event.target.classList.contains('remove-field')) {
      event.target.parentElement.remove();
    }
  }

  async function saveConfig() {
    const fieldItems = document.querySelectorAll('#fields-container .field-item'); // More specific selector
    const fields = [];
    
    fieldItems.forEach(item => {
      const nameInput = item.querySelector('.field-name');
      const selectorsInput = item.querySelector('.field-selectors');
      const name = nameInput ? nameInput.value.trim() : '';
      const selectorsText = selectorsInput ? selectorsInput.value.trim() : '';
      
      if (name && selectorsText) {
        const selectors = selectorsText.split(',').map(s => s.trim()).filter(s => s);
        if (selectors.length > 0) {
            fields.push({ name, selectors });
        }
      }
    });

    const scanKeywords = {
        start: startKeywordInput.value.trim(),
        end: endKeywordInput.value.trim()
    };
    
    try {
      await chrome.storage.sync.set({ formFields: fields, scanKeywords: scanKeywords });
      statusEl.textContent = '配置保存成功！/ Configuration saved successfully!';
      statusEl.style.color = 'green';
    } catch (error) {
      statusEl.textContent = '保存失败: ' + error.message + ' / Save failed: ' + error.message;
      statusEl.style.color = 'red';
      console.error('保存配置错误:', error);
    }
  }

  async function loadConfig() {
    try {
      const result = await chrome.storage.sync.get(['formFields', 'scanKeywords']);
      
      let fieldsToLoad = defaultFields;
      if (result.formFields && result.formFields.length > 0) {
        fieldsToLoad = result.formFields;
      }
      fieldsContainer.innerHTML = ''; 
      fieldIndex = 0; 
      fieldsToLoad.forEach(field => createFieldElement(field));

      if (result.scanKeywords) {
        startKeywordInput.value = result.scanKeywords.start || '';
        endKeywordInput.value = result.scanKeywords.end || '';
      }

    } catch (error) {
      console.error('加载配置失败 / Failed to load configuration:', error);
      fieldsContainer.innerHTML = '';
      fieldIndex = 0;
      defaultFields.forEach(field => createFieldElement(field));
      // Keep keyword fields empty if load fails
      startKeywordInput.value = '';
      endKeywordInput.value = '';
    }
  }
});