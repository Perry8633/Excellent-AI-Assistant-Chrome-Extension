document.addEventListener('DOMContentLoaded', () => {
  const exportBtn = document.getElementById('exportBtn');
  const settingsBtn = document.getElementById('settingsBtn');
  const statusEl = document.getElementById('status');

  exportBtn.addEventListener('click', exportFormData);
  settingsBtn.addEventListener('click', openOptionsPage);

  async function exportFormData() {
    statusEl.textContent = '正在获取表单数据...';
    try {
      const tabs = await chrome.tabs.query({active: true, currentWindow: true});
      const response = await chrome.tabs.sendMessage(tabs[0].id, {action: "exportData"});
      
      if (response.data && Object.keys(response.data).length > 0) {
        const saveResult = await chrome.runtime.sendMessage({
          action: "saveCSV",
          data: response.data
        });
        
        statusEl.textContent = saveResult.status === "success" 
          ? "数据导出成功！" 
          : "导出失败，请重试";
      } else {
        statusEl.textContent = "未找到表单数据，请检查页面表单结构";
      }
    } catch (error) {
      statusEl.textContent = `操作失败: ${error.message}`;
      console.error(error);
    }
  }

  function openOptionsPage() {
    chrome.runtime.openOptionsPage();
  }
});