chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "exportData") {
    // Chain the promises: get scan keywords, then form fields, then extract values
    chrome.storage.sync.get('scanKeywords').then(keywordConfig => {
        getFormFields().then(fields => {
            const data = extractFormValues(fields, keywordConfig.scanKeywords);
            sendResponse({data});
        }).catch(error => {
            sendResponse({error: error.message});
            console.error("Error getting form fields:", error);
        });
    }).catch(error => {
        sendResponse({error: error.message});
        console.error("Error getting scan keywords:", error);
    });
    return true; // Keep message channel open for async response
  }
  
  // 修改处理getSelectedTableData消息的逻辑
  if (request.action === "getSelectedTableData") {
    console.log("收到getSelectedTableData请求，当前选中数据：", selectedTableDataForExport);
    
    // 检查是否有有效的表格数据
    if (selectedTableDataForExport && Array.isArray(selectedTableDataForExport) && selectedTableDataForExport.length > 0) {
      // 验证数据格式：确保是二维数组
      const isValidTableData = selectedTableDataForExport.every(row => Array.isArray(row));
      
      if (isValidTableData) {
        console.log("发送有效的表格数据到background.js", selectedTableDataForExport);
        // 发送选中的表格数据到background.js进行CSV导出
        chrome.runtime.sendMessage({
          action: "saveCSV",
          data: selectedTableDataForExport
        }, response => {
          if (chrome.runtime.lastError) {
            console.error("发送表格数据失败:", chrome.runtime.lastError);
            sendResponse({error: chrome.runtime.lastError.message});
          } else {
            console.log("表格数据已发送到background.js进行CSV导出", response);
            sendResponse({status: "success"});
          }
        });
      } else {
        console.error("选中的数据格式不正确，不是二维数组:", selectedTableDataForExport);
        sendResponse({error: "选中的数据格式不正确"});
      }
    } else {
      console.log("没有选中有效的表格数据，尝试智能检测页面表格");
      
      // 如果没有选中数据，尝试智能检测页面中的表格
      const detectedTableData = detectAndExtractTableData();
      if (detectedTableData && detectedTableData.length > 0) {
        console.log("检测到页面表格数据:", detectedTableData);
        chrome.runtime.sendMessage({
          action: "saveCSV",
          data: detectedTableData
        }, response => {
          if (chrome.runtime.lastError) {
            console.error("发送检测到的表格数据失败:", chrome.runtime.lastError);
            sendResponse({error: chrome.runtime.lastError.message});
          } else {
            console.log("检测到的表格数据已发送到background.js进行CSV导出", response);
            sendResponse({status: "success"});
          }
        });
      } else {
        sendResponse({status: "no_selection", message: "未找到可导出的表格数据"});
      }
    }
    return true; // 保持消息通道开放以进行异步响应
  }
});

async function getFormFields() {
  // 优先使用用户自定义字段配置
  const config = await chrome.storage.sync.get('formFields');
  if (config.formFields && config.formFields.length > 0) {
    return config.formFields;
  }

  // fallback to default fields
  return [
    {name: "名称", selectors: ["[id*='name']", "[name*='title']", "[id*='company-name']", "[name*='company-name']"]},
    {name: "类型", selectors: ["[id*='type']", "[name*='type']", "[id*='category']", "[name*='category']"]},
    {name: "受限制主体编号", selectors: ["[id*='number']", "[name*='code']", "[id*='entity-id']", "[name*='entity-id']", "[id*='company-code']"]},
    {name: "国家/地区", selectors: ["[id*='country']", "[name*='region']", "[name*='country_region']"]},
    {name: "城市", selectors: ["[id*='city']", "[name*='city']"]},
    {name: "详细地址", selectors: ["[id*='address']", "[name*='addr']", "[id*='street']"]},
    {name: "邮编", selectors: ["[id*='postcode']", "[name*='zip']", "[id*='postal_code']"]},
    {name: "备注", selectors: ["[id*='remark']", "[name*='note']", "textarea[name*='comment']", "textarea[id*='comment']"]}
    // "扫描主体名称" is added dynamically in extractFormValues
  ];
}

function extractFormValues(fields, scanKeywords) {
  const data = {};
  fields.forEach(field => {
    const element = findFormElement(field.selectors, field.name);
    data[field.name] = element ? getElementValue(element).trim() : ""; 
  });

  // Extract "扫描主体名称" using keywords
  let scannedName = "";
  if (scanKeywords && scanKeywords.start && scanKeywords.end) {
    const pageText = document.body.innerText;
    const startIndex = pageText.indexOf(scanKeywords.start);
    const endIndex = pageText.indexOf(scanKeywords.end);

    if (startIndex !== -1 && endIndex !== -1 && endIndex > startIndex) {
      // Extract text between the end of startKeyword and the beginning of endKeyword
      scannedName = pageText.substring(startIndex + scanKeywords.start.length, endIndex).trim();
    }
  }
  data["扫描主体名称"] = scannedName;

  return data;
}

// 新增：智能检测页面表格数据的函数
function detectAndExtractTableData() {
  console.log("开始智能检测页面表格...");
  
  // 查找页面中的所有表格
  const tables = document.querySelectorAll('table');
  console.log(`找到 ${tables.length} 个表格`);
  
  if (tables.length === 0) {
    // 如果没有标准表格，尝试检测类似表格的结构
    return detectTableLikeStructures();
  }
  
  // 选择最大的表格（通常是主要数据表格）
  let largestTable = null;
  let maxCells = 0;
  
  tables.forEach(table => {
    const cellCount = table.querySelectorAll('td, th').length;
    if (cellCount > maxCells) {
      maxCells = cellCount;
      largestTable = table;
    }
  });
  
  if (largestTable) {
    console.log("选择最大的表格进行数据提取", largestTable);
    return extractTableData(largestTable);
  }
  
  return [];
}

// 新增：检测类似表格的结构（如div布局的表格）
function detectTableLikeStructures() {
  console.log("检测类似表格的结构...");
  
  // 查找具有表格特征的元素
  const potentialTables = document.querySelectorAll(
    '[class*="table"], [class*="grid"], [class*="data"], [role="table"], [role="grid"]'
  );
  
  for (const element of potentialTables) {
    const rows = element.querySelectorAll(
      '[role="row"], tr, [class*="row"], .table-row'
    );
    
    if (rows.length > 1) { // 至少有2行数据
      console.log("找到类似表格的结构", element);
      return extractTableLikeData(element, rows);
    }
  }
  
  return [];
}

// 新增：从标准表格提取数据
function extractTableData(table) {
  const rows = Array.from(table.rows);
  const tableData = [];
  
  rows.forEach(row => {
    const cells = Array.from(row.cells);
    const rowData = cells.map(cell => cell.innerText.trim());
    if (rowData.some(cell => cell !== '')) { // 只添加非空行
      tableData.push(rowData);
    }
  });
  
  console.log("提取的表格数据:", tableData);
  return tableData;
}

// 新增：从类似表格的结构提取数据
function extractTableLikeData(container, rows) {
  const tableData = [];
  
  rows.forEach(row => {
    const cells = row.querySelectorAll(
      '[role="cell"], [role="gridcell"], td, th, [class*="cell"], .table-cell'
    );
    
    if (cells.length > 0) {
      const rowData = Array.from(cells).map(cell => cell.innerText.trim());
      if (rowData.some(cell => cell !== '')) { // 只添加非空行
        tableData.push(rowData);
      }
    }
  });
  
  console.log("提取的类似表格数据:", tableData);
  return tableData;
}

// 改进的表格选择检测
let selectedTableDataForExport = [];

document.addEventListener('mouseup', (event) => {
  const selection = window.getSelection();
  if (!selection || selection.rangeCount === 0 || selection.isCollapsed) {
    selectedTableDataForExport = [];
    return;
  }

  console.log("检测到文本选择，开始分析...");
  const range = selection.getRangeAt(0);
  let commonAncestor = range.commonAncestorContainer;

  // 查找表格元素
  let tableElement = commonAncestor;
  while (tableElement && tableElement.nodeType !== Node.ELEMENT_NODE) {
    tableElement = tableElement.parentNode;
  }
  
  while (tableElement && tableElement.nodeName !== 'TABLE') {
    tableElement = tableElement.parentNode;
  }

  if (!tableElement) {
    console.log("未在标准表格中检测到选择，尝试检测其他表格结构");
    // 尝试检测其他类型的表格结构
    selectedTableDataForExport = detectSelectionInTableLikeStructure(selection, range);
    return;
  }

  console.log("在表格中检测到选择", tableElement);
  const rows = Array.from(tableElement.rows);
  const tempSelectedData = [];

  for (const row of rows) {
    const cellsInRow = Array.from(row.cells);
    const selectedCellsInRow = [];
    
    for (const cell of cellsInRow) {
      if (selection.containsNode(cell, true) || range.intersectsNode(cell)) {
        selectedCellsInRow.push(cell.innerText.trim());
      }
    }
    
    if (selectedCellsInRow.length > 0) {
      tempSelectedData.push(selectedCellsInRow);
    }
  }
  
  if (tempSelectedData.length > 0) {
    // 标准化行长度
    let maxCols = Math.max(...tempSelectedData.map(row => row.length));
    selectedTableDataForExport = tempSelectedData.map(row => {
      const newRow = [...row];
      while (newRow.length < maxCols) {
        newRow.push("");
      }
      return newRow;
    });
    console.log("提取的选中表格数据:", selectedTableDataForExport);
  } else {
    selectedTableDataForExport = [];
  }
});

// 新增：在类似表格结构中检测选择
function detectSelectionInTableLikeStructure(selection, range) {
  console.log("在类似表格结构中检测选择...");
  
  // 查找包含选择的容器
  let container = range.commonAncestorContainer;
  while (container && container.nodeType !== Node.ELEMENT_NODE) {
    container = container.parentNode;
  }
  
  // 向上查找可能的表格容器
  while (container && !container.matches('[class*="table"], [class*="grid"], [class*="data"], [role="table"], [role="grid"]')) {
    container = container.parentNode;
    if (container === document.body) break;
  }
  
  if (!container || container === document.body) {
    console.log("未找到表格容器");
    return [];
  }
  
  console.log("找到表格容器", container);
  
  // 查找行元素
  const rows = container.querySelectorAll(
    '[role="row"], tr, [class*="row"], .table-row'
  );
  
  const tempSelectedData = [];
  
  rows.forEach(row => {
    const cells = row.querySelectorAll(
      '[role="cell"], [role="gridcell"], td, th, [class*="cell"], .table-cell'
    );
    
    const selectedCellsInRow = [];
    
    cells.forEach(cell => {
      if (selection.containsNode(cell, true) || range.intersectsNode(cell)) {
        selectedCellsInRow.push(cell.innerText.trim());
      }
    });
    
    if (selectedCellsInRow.length > 0) {
      tempSelectedData.push(selectedCellsInRow);
    }
  });
  
  if (tempSelectedData.length > 0) {
    let maxCols = Math.max(...tempSelectedData.map(row => row.length));
    const result = tempSelectedData.map(row => {
      const newRow = [...row];
      while (newRow.length < maxCols) {
        newRow.push("");
      }
      return newRow;
    });
    console.log("从类似表格结构提取的选中数据:", result);
    return result;
  }
  
  return [];
}

// findFormElement and getElementValue functions remain the same as in your provided utils.js or previous content.js
// Make sure they are available in this scope.
// If utils.js is imported via manifest.json, they should be.