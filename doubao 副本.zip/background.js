// 初始化右键菜单
function createContextMenus() {
    chrome.contextMenus.create({
        id: 'export-main-menu',
        title: '导出页面数据',
        contexts: ['page', 'selection']
    });

    chrome.contextMenus.create({
        id: 'export-by-keyword',
        parentId: 'export-main-menu',
        title: '按关键词提取到CSV（含PDF）',
        contexts: ['page', 'selection']
    });

    chrome.contextMenus.create({
        id: 'export-full-page',
        parentId: 'export-main-menu',
        title: '全文导出CSV并下载PDF',
        contexts: ['page']
    });
}

// 安装/更新时初始化菜单
chrome.runtime.onInstalled.addListener(() => {
    chrome.contextMenus.removeAll(() => {
        createContextMenus();
    });
});

// 菜单点击事件处理
chrome.contextMenus.onClicked.addListener(async (info, tab) => {
    try {
        if (!tab?.id) throw new Error('无效标签页');

        // 获取用户配置
        const { settings } = await chrome.storage.sync.get('settings');
        if (!settings?.keywords?.length) {
            chrome.notifications.create({
                type: 'basic',
                title: '配置缺失',
                message: '请先在设置页配置关键词'
            });
            return;
        }

        if (info.menuItemId === 'export-by-keyword') {
            // 关键词提取模式（支持选中文本）
            const { data: keywordData } = await chrome.tabs.sendMessage(tab.id, {
                action: 'extractByKeywords',
                keywords: settings.keywords,
                selectionText: info.selectionText
            });
            
            // 下载CSV（含BOM头防乱码）
            const csvContent = `\ufeff${settings.headers.join(',')}\n${keywordData.join(',')}`;
            const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8' });
            const url = URL.createObjectURL(blob);
            
            chrome.downloads.download({
                url,
                filename: `关键词导出_${new Date().toISOString().replace(/[:.]/g, '-')}.csv`
            });
            URL.revokeObjectURL(url);

            // 下载关联PDF（示例限制3并发）
            const { pdfLinks } = await chrome.tabs.sendMessage(tab.id, { action: 'getPdfLinks' });
            let activeDownloads = 0;
            for (const link of [...new Set(pdfLinks)]) {
                while (activeDownloads >= 3) await new Promise(r => setTimeout(r, 1000));
                activeDownloads++;
                chrome.downloads.download({ url: link }, () => activeDownloads--);
            }

        } else if (info.menuItemId === 'export-full-page') {
            // 全文导出模式
            const { fullText, pdfLinks } = await chrome.tabs.sendMessage(tab.id, { action: 'getFullPageData' });
            
            // 生成并下载CSV
            const csvContent = `\ufeff页面全文\n${fullText.replace(/\n/g, ' ')}`;
            const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8' });
            const url = URL.createObjectURL(blob);
            
            chrome.downloads.download({
                url,
                filename: `全文导出_${new Date().toISOString().replace(/[:.]/g, '-')}.csv`
            });
            URL.revokeObjectURL(url);

            // 下载PDF（带重试逻辑）
            pdfLinks.forEach(link => {
                chrome.downloads.download({ url: link }, (downloadId) => {
                    chrome.downloads.onChanged.addListener((delta) => {
                        if (delta.id === downloadId && delta.error) {
                            chrome.downloads.download({ url: link }, () => {
                                chrome.notifications.create({
                                    type: 'basic',
                                    title: 'PDF重试',
                                    message: `重新下载：${link}`
                                });
                            });
                        }
                    });
                });
            });
        }
    } catch (error) {
        console.error('导出失败:', error);
        chrome.notifications.create({
            type: 'basic',
            title: '导出失败',
            message: '请检查页面内容或配置后重试'
        });
    }
});
    