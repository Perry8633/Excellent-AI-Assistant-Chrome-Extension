// 关键词区间提取函数（支持选中文本增强）
function extractByKeywords(keywords, selectionText) {
    const sourceText = selectionText || document.body.innerText;
    const results = [];
    
    for (let i = 0; i < keywords.length - 1; i++) {
        const startIdx = sourceText.indexOf(keywords[i]);
        const endIdx = sourceText.indexOf(keywords[i + 1], startIdx + 1);
        
        if (startIdx === -1 || endIdx === -1) {
            results.push('未匹配');
            continue;
        }
        
        const content = sourceText.slice(startIdx + keywords[i].length, endIdx).trim();
        results.push(content.replace(/,/g, '，')); // 替换逗号防CSV格式错误
    }
    
    return results;
}

// PDF链接检测函数（支持自定义前缀）
function getPdfLinks() {
    const pdfPrefixes = ['https://idrive.zte.com.cn/zte-km-clouddudm-clouddisk/objects/downloadByToken/'];
    const links = Array.from(document.querySelectorAll('a[href]'))
        .map(a => a.href)
        .filter(href => {
            const isPdfSuffix = href.toLowerCase().endsWith('.pdf');
            const isCustomPrefix = pdfPrefixes.some(prefix => href.startsWith(prefix));
            return isPdfSuffix || isCustomPrefix;
        })
        .map(href => new URL(href, window.location.href).href); // 转换绝对路径
    
    return [...new Set(links)]; // 去重
}

// 消息监听处理
chrome.runtime.onMessage.addListener(async (request, sender, sendResponse) => {
    try {
        if (request.action === 'extractByKeywords') {
            const data = extractByKeywords(request.keywords, request.selectionText);
            sendResponse({ data });
        } else if (request.action === 'getPdfLinks') {
            const pdfLinks = getPdfLinks();
            sendResponse({ pdfLinks });
        } else if (request.action === 'getFullPageData') {
            const fullText = document.body.innerText.replace(/\n+/g, '\n');
            const pdfLinks = getPdfLinks();
            sendResponse({ fullText, pdfLinks });
        }
    } catch (error) {
        sendResponse({ error: '数据提取失败' });
    }
    return true; // 保持异步响应
});
    