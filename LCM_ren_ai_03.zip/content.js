chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "exportData") {
    // Chain the promises: get scan keywords, then form fields, then extract values
    chrome.storage.sync.get('scanKeywords').then(keywordConfig => {
        getFormFields().then(fields => {
            const data = extractFormValues(fields, keywordConfig.scanKeywords);
            sendResponse({data});
        }).catch(error => {
            sendResponse({error: error.message});
            console.error("Error getting form fields:", error);
        });
    }).catch(error => {
        sendResponse({error: error.message});
        console.error("Error getting scan keywords:", error);
    });
    return true; // Keep message channel open for async response
  }
  
  // 添加处理getSelectedTableData消息的逻辑
  if (request.action === "getSelectedTableData") {
    if (selectedTableDataForExport && selectedTableDataForExport.length > 0) {
      // 发送选中的表格数据到background.js进行CSV导出
      chrome.runtime.sendMessage({
        action: "saveCSV",
        data: selectedTableDataForExport
      }, response => {
        if (chrome.runtime.lastError) {
          console.error("发送表格数据失败:", chrome.runtime.lastError);
          sendResponse({error: chrome.runtime.lastError.message});
        } else {
          console.log("表格数据已发送到background.js进行CSV导出", response);
          sendResponse({status: "success"});
        }
      });
    } else {
      console.log("没有选中有效的表格数据");
      sendResponse({status: "no_selection"});
    }
    return true; // 保持消息通道开放以进行异步响应
  }
});

async function getFormFields() {
  // 优先使用用户自定义字段配置
  const config = await chrome.storage.sync.get('formFields');
  if (config.formFields && config.formFields.length > 0) {
    return config.formFields;
  }

  // fallback to default fields
  return [
    {name: "名称", selectors: ["[id*='name']", "[name*='title']", "[id*='company-name']", "[name*='company-name']"]},
    {name: "类型", selectors: ["[id*='type']", "[name*='type']", "[id*='category']", "[name*='category']"]},
    {name: "受限制主体编号", selectors: ["[id*='number']", "[name*='code']", "[id*='entity-id']", "[name*='entity-id']", "[id*='company-code']"]},
    {name: "国家/地区", selectors: ["[id*='country']", "[name*='region']", "[name*='country_region']"]},
    {name: "城市", selectors: ["[id*='city']", "[name*='city']"]},
    {name: "详细地址", selectors: ["[id*='address']", "[name*='addr']", "[id*='street']"]},
    {name: "邮编", selectors: ["[id*='postcode']", "[name*='zip']", "[id*='postal_code']"]},
    {name: "备注", selectors: ["[id*='remark']", "[name*='note']", "textarea[name*='comment']", "textarea[id*='comment']"]}
    // "扫描主体名称" is added dynamically in extractFormValues
  ];
}

function extractFormValues(fields, scanKeywords) {
  const data = {};
  fields.forEach(field => {
    const element = findFormElement(field.selectors, field.name);
    data[field.name] = element ? getElementValue(element).trim() : ""; 
  });

  // Extract "扫描主体名称" using keywords
  let scannedName = "";
  if (scanKeywords && scanKeywords.start && scanKeywords.end) {
    const pageText = document.body.innerText;
    const startIndex = pageText.indexOf(scanKeywords.start);
    const endIndex = pageText.indexOf(scanKeywords.end);

    if (startIndex !== -1 && endIndex !== -1 && endIndex > startIndex) {
      // Extract text between the end of startKeyword and the beginning of endKeyword
      scannedName = pageText.substring(startIndex + scanKeywords.start.length, endIndex).trim();
    }
  }
  data["扫描主体名称"] = scannedName;

  return data;
}

let selectedTableDataForExport = []; 

document.addEventListener('mouseup', (event) => {
  const selection = window.getSelection();
  if (!selection || selection.rangeCount === 0 || selection.isCollapsed) {
    selectedTableDataForExport = []; 
    return;
  }

  const range = selection.getRangeAt(0);
  let commonAncestor = range.commonAncestorContainer;

  let tableElement = commonAncestor;
  while (tableElement && tableElement.nodeName !== 'TABLE') {
    tableElement = tableElement.parentNode;
  }

  if (!tableElement) {
    selectedTableDataForExport = []; 
    return;
  }

  const rows = Array.from(tableElement.rows);
  const tempSelectedData = [];

  for (const row of rows) {
    const cellsInRow = Array.from(row.cells);
    const selectedCellsInRow = [];
    let rowHasSelection = false;
    for (const cell of cellsInRow) {
      if (selection.containsNode(cell, true) || range.intersectsNode(cell)) {
        selectedCellsInRow.push(cell.innerText.trim());
        rowHasSelection = true;
      } 
    }
    if (selectedCellsInRow.length > 0) {
      tempSelectedData.push(selectedCellsInRow);
    }
  }
  
  if (tempSelectedData.length > 0) {
     let maxCols = 0;
     tempSelectedData.forEach(row => {
         if (row.length > maxCols) maxCols = row.length;
     });
     selectedTableDataForExport = tempSelectedData.map(row => {
         const newRow = [...row];
         while(newRow.length < maxCols) {
             newRow.push("");
         }
         return newRow;
     });
  } else {
     selectedTableDataForExport = [];
  }
});

// findFormElement and getElementValue functions remain the same as in your provided utils.js or previous content.js
// Make sure they are available in this scope.
// If utils.js is imported via manifest.json, they should be.