// 内容脚本 - 用于与页面交互
(function() {
  'use strict';

  const TABLE_SELECTOR_ATTR = 'data-table-extractor-target';
  let highlightedTable = null; // Keep track of the currently highlighted table

  // 监听右键点击事件
  document.addEventListener('contextmenu', function(e) {
    const element = document.elementFromPoint(e.clientX, e.clientY);
    const table = element ? element.closest('table') : null;

    // Clear previous attribute from any table
    const previouslyMarkedTable = document.querySelector(`[${TABLE_SELECTOR_ATTR}="true"]`);
    if (previouslyMarkedTable) {
      previouslyMarkedTable.removeAttribute(TABLE_SELECTOR_ATTR);
      if (highlightedTable === previouslyMarkedTable) { // only remove old highlight if it's the one we are clearing attr from
          removeHighlight(highlightedTable);
      }
    }
    
    if (highlightedTable && highlightedTable !== table) { // If a different table was highlighted, clear its highlight
        removeHighlight(highlightedTable);
        highlightedTable = null;
    }

    if (table) {
      table.setAttribute(TABLE_SELECTOR_ATTR, 'true');
      highlightTable(table);
      highlightedTable = table; // Store the currently highlighted table
      
      // Optional: remove highlight after a delay, but keep the attribute until extraction
      setTimeout(() => {
        if (table.getAttribute(TABLE_SELECTOR_ATTR) === 'true') { // Only remove highlight if it's still the target
             // We won't remove highlight here anymore, background will tell us when to clear or it clears attribute itself
        }
      }, 3500); // Slightly longer than before, just for visual cue
    }
  }, true); // Use capture phase to ensure this runs before other context menu listeners if any

  // 高亮表格 (Highlight table)
  function highlightTable(table) {
    if(table) {
      table.style.outline = '3px solid #007cba';
      table.style.backgroundColor = 'rgba(0, 124, 186, 0.1)';
    }
  }
  
  // 移除高亮 (Remove highlight)
  function removeHighlight(table) {
    if(table) {
      table.style.outline = '';
      table.style.backgroundColor = '';
    }
  }
  
  // 监听来自background script的消息 (Listen for messages from background script)
  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    let responseData = {};
    if (request.action === 'getRightClickedTableInfo') {
      const targetTableElement = document.querySelector(`[${TABLE_SELECTOR_ATTR}="true"]`);
      if (targetTableElement) {
        sendResponse({ success: true, tableFound: true, selector: `[${TABLE_SELECTOR_ATTR}="true"]` });
      } else {
        sendResponse({ success: true, tableFound: false });
      }
      return true;
    } else if (request.action === 'clearTableHighlightAndAttribute') {
        const targetTableElement = document.querySelector(`[${TABLE_SELECTOR_ATTR}="true"]`);
        if (targetTableElement) {
            removeHighlight(targetTableElement);
            targetTableElement.removeAttribute(TABLE_SELECTOR_ATTR);
            highlightedTable = null; 
            sendResponse({ success: true, cleared: true });
        } else {
            sendResponse({ success: false, cleared: false, message: "No target table found to clear." });
        }
        return true;
    } else if (request.action === 'getSelectedText') {
      const selectedText = window.getSelection().toString().trim();
      sendResponse({ selectedText: selectedText });
      return true;
    } else if (request.action === "extractTextByKeywords" || request.action === "extractFullText") {
        // This is the new handler for the new context menu items
        let extractedText = "";
        if (request.action === "extractTextByKeywords") {
            // request.keywords will come from background.js, which gets them from storage
            if (request.keywords && request.keywords.length > 0) {
                extractedText = extractTextUsingKeywords(document.body.innerText, request.keywords);
                responseData.source = 'keywords';
            } else {
                extractedText = "Error: No keywords provided for extraction by content script.";
            }
        } else { // extractFullText
            extractedText = document.body.innerText;
            responseData.source = 'fullText';
        }
        responseData.text = extractedText;
        // request.pdfKeywords and request.pdfRegex will come from background.js
        responseData.pdfLinks = findPdfLinksOnPage(request.pdfKeywords, request.pdfRegex);
        
        // Send extracted content and PDF links back to background.js
        chrome.runtime.sendMessage({ action: "contentExtracted", ...responseData });
        sendResponse({ success: true, message: "Content extraction processing in content script." });
        return true; // Indicate async response if sendMessage itself is async, or if other logic here is.
    }
    // Fallback or handling for older/other actions if necessary
    // console.log("Message received in content.js: ", request.action);
    return true; // Keep the message channel open for sendResponse
  });

// Renamed and refined function for extracting text based on keywords
function extractTextUsingKeywords(text, keywords) {
    let result = "";
    if (!keywords || keywords.length === 0) return "No keywords provided.";

    const lines = text.split('\n'); // Split text into lines
    const foundTexts = [];

    keywords.forEach(kw => {
        if (!kw || kw.trim() === '') return; // Skip empty keywords
        const keywordRegex = new RegExp(escapeRegExp(kw), 'gi'); // Case-insensitive search for the keyword
        lines.forEach(line => {
            if (keywordRegex.test(line)) {
                // If the line contains the keyword, add the entire line
                // Avoid adding duplicate lines if multiple keywords match the same line, 
                // or if the same keyword matches multiple times in a line (though regex 'g' handles the latter within the line).
                // The current logic will add a line if *any* keyword matches it.
                // If a line matches multiple keywords, it will be added for each match if we don't check for duplicates.
                // For CSV, it might be better to have: Keyword, Matched Line
                // However, the current background.js expects a block of text.
                // Let's stick to collecting unique lines that match any keyword for now.
                if (!foundTexts.includes(line.trim())) {
                    foundTexts.push(line.trim());
                }
            }
        });
    });

    if (foundTexts.length > 0) {
        // 处理CSV格式，替换逗号防止格式错误
        const processedTexts = foundTexts.map(text => text.replace(/,/g, '，'));
        result = processedTexts.join('\n'); // Join found lines with a single newline, as background.js's CSV formatter will handle it
    } else {
        result = "No text found containing the specified keywords.";
    }
    return result;
}

// Helper function to escape characters for use in a regular expression
function escapeRegExp(string) {
    return string.replace(/[.*+\-?^{}()|[\]\\]/g, '\\$&');
}

// Renamed and refined function for finding PDF links (enhanced with better URL handling)
function findPdfLinksOnPage(keywords, regexPattern) {
    const pdfPrefixes = ['https://idrive.zte.com.cn/zte-km-clouddudm-clouddisk/objects/downloadByToken/'];
    const aTags = document.getElementsByTagName('a');
    let regex = null;

    if (regexPattern) {
        try {
            regex = new RegExp(regexPattern, 'i');
        } catch (e) {
            console.error("Invalid PDF regex pattern in content.js: ", e);
        }
    }

    const links = Array.from(aTags)
        .map(a => {
            const href = a.href ? new URL(a.href, document.baseURI).href : null;
            const linkText = (a.innerText || a.textContent || "").trim();
            return { href, linkText };
        })
        .filter(({ href }) => href) // 过滤无效链接
        .filter(({ href, linkText }) => {
            // Priority 1: Ends with .pdf
            if (href.toLowerCase().endsWith('.pdf')) {
                return true;
            }
            
            // Priority 2: Matches custom prefixes
            if (pdfPrefixes.some(prefix => href.startsWith(prefix))) {
                return true;
            }
            
            // Priority 3: Matches regex (if provided)
            if (regex && (regex.test(href) || (linkText && regex.test(linkText)))) {
                return true;
            }
            
            // Priority 4: Matches keywords (if provided)
            if (keywords && keywords.length > 0) {
                return keywords.some(keyword => {
                    if (!keyword) return false;
                    const keywordLower = keyword.toLowerCase();
                    return href.toLowerCase().includes(keywordLower) || 
                           (linkText && linkText.toLowerCase().includes(keywordLower));
                });
            }
            
            return false;
        })
        .map(({ href }) => href);

    return [...new Set(links)]; // 去重并返回
}

})();