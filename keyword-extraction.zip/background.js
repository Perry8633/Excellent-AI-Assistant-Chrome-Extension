// 创建右键菜单
chrome.runtime.onInstalled.addListener(() => {
    // 移除旧的菜单项
    chrome.contextMenus.removeAll(() => {
        // 创建新的父菜单项
        chrome.contextMenus.create({
            id: "savePageContent",
            title: "Save Page Content as CSV and Download PDFs",
            contexts: ["page"]
        });
        // 创建子菜单项: 按关键词提取
        chrome.contextMenus.create({
            id: "extractByKeywords",
            title: "Extract to CSV by Keywords",
            contexts: ["page"],
            parentId: "savePageContent"
        });
        // 创建子菜单项: 复制全文
        chrome.contextMenus.create({
            id: "copyFullText",
            title: "Copy Full Text to CSV",
            contexts: ["page"],
            parentId: "savePageContent"
        });

        // 保留原有的 LCM to WPS 菜单及其子菜单，如果仍然需要的话
        // 如果不再需要，可以注释或删除以下代码
        chrome.contextMenus.create({
            id: "lcmToWps",
            title: "LCM to WPS (Legacy)", // 更改标题以区分
            contexts: ["page", "selection"]
        });
        chrome.contextMenus.create({
            id: "extractTable",
            title: "提取表格数据到WPS",
            contexts: ["page"],
            parentId: "lcmToWps"
        });
        chrome.contextMenus.create({
            id: "extractText",
            title: "提取选中文本内容到WPS", // 明确是选中文本
            contexts: ["selection"],
            parentId: "lcmToWps"
        });
        chrome.contextMenus.create({
            id: "extractKeywordsOld", // 更改ID以避免冲突
            title: "提取关键词内容到WPS (Legacy)", // 更改标题以区分
            contexts: ["page"],
            parentId: "lcmToWps"
        });
    });
});

// 监听右键菜单点击事件
chrome.contextMenus.onClicked.addListener((info, tab) => {
    if (info.menuItemId === "extractByKeywords" || info.menuItemId === "copyFullText") {
        chrome.scripting.executeScript({
            target: { tabId: tab.id },
            files: ['content.js']
        }, () => {
            if (chrome.runtime.lastError) {
                console.error("Script injection failed: ", chrome.runtime.lastError.message);
                return;
            }
            const actionType = info.menuItemId === "extractByKeywords" ? "extractTextByKeywords" : "extractFullText";
            // 获取用户定义的关键词（如果适用）
            chrome.storage.sync.get(['keywordsForExtraction', 'pdfKeywords', 'pdfRegex'], (settings) => {
                chrome.tabs.sendMessage(tab.id, {
                action: actionType,
                keywords: settings.keywordsForExtraction || [], // 用于文本提取的关键词
                pdfKeywords: settings.pdfKeywords || [], // 用于PDF链接查找的关键词
                pdfRegex: settings.pdfRegex || '' // 用于PDF链接查找的正则表达式
            }, (response) => {
                if (chrome.runtime.lastError) {
                    console.error('消息发送失败:', chrome.runtime.lastError);
                    showNotification('提取失败', '无法与页面通信，请刷新页面后重试');
                }
                // 由 content.js 通过 sendMessage 主动回传数据，background.js 的 onMessage 负责处理下载
                // 这里无需处理 response
            });
            });
        });
    } else if (info.menuItemId === "extractTable") {
        chrome.scripting.executeScript({
            target: { tabId: tab.id },
            files: ['content.js']
        }, () => {
            if (chrome.runtime.lastError) {
                console.error("Script injection failed: ", chrome.runtime.lastError.message);
                return;
            }
            chrome.storage.sync.get(['fileFormat', 'tableDetection'], (settings) => {
                chrome.tabs.sendMessage(tab.id, {
                    action: "extractTableData",
                    settings: settings
                });
            });
        });
    } else if (info.menuItemId === "extractText") {
        const selectedText = info.selectionText;
        if (selectedText) {
            chrome.storage.sync.get(['fileFormat'], (settings) => {
                const csvData = convertToCSV(selectedText, settings.fileFormat || 'csv');
                downloadCSV(csvData, `extracted_selection.${settings.fileFormat || 'csv'}`);
            });
        }
    } else if (info.menuItemId === "extractKeywordsOld") { // 使用新的ID
        chrome.scripting.executeScript({
            target: { tabId: tab.id },
            files: ['content.js']
        }, () => {
            if (chrome.runtime.lastError) {
                console.error("Script injection failed: ", chrome.runtime.lastError.message);
                return;
            }
            chrome.storage.sync.get(['keywords', 'fileFormat'], (settings) => {
                // 注意：这里的 'keywords' 是旧的关键词设置，可能需要与 'keywordsForExtraction' 区分
                chrome.tabs.sendMessage(tab.id, {
                    action: "extractKeywordData", // 这个action可能也需要更新或区分
                    keywords: settings.keywords || [],
                    fileFormat: settings.fileFormat || 'csv'
                });
            });
        });
    }
});

function fetchSettingsAndInject(tabId, tableSelector) {
  chrome.storage.sync.get(['keywordSettings', 'filename', 'dateFormat', 'includeHeaders', 'autoDetect'], (settings) => {
    const keywordSettings = settings.keywordSettings || [];
    const filename = settings.filename || 'table_data';
    const dateFormat = settings.dateFormat !== undefined ? settings.dateFormat : false;
    const includeHeaders = settings.includeHeaders !== undefined ? settings.includeHeaders : true;
    const autoDetect = settings.autoDetect !== undefined ? settings.autoDetect : true;

    chrome.scripting.executeScript({
      target: { tabId: tabId },
      function: extractTableData,
      args: [tableSelector, keywordSettings, filename, dateFormat, includeHeaders, autoDetect]
    });
  });
}

// Helper function to get clean text from a cell
function getCellText(cell) {
  if (!cell) return '';
  let text = cell.textContent || cell.innerText || '';
  return text.trim().replace(/\s+/g, ' ');
}

// Helper function to find a keyword in a table
// Searches th first, then td. Case-insensitive.
function findKeywordCellInfo(table, keyword) {
  if (!table || !keyword) return null;
  const rows = table.rows;
  const lowerKeyword = keyword.toLowerCase();

  // Pass 1: Search <th> elements
  for (let i = 0; i < rows.length; i++) {
    const cells = rows[i].cells;
    for (let j = 0; j < cells.length; j++) {
      const cell = cells[j];
      if (cell.tagName === 'TH') {
        const cellText = getCellText(cell);
        if (cellText.toLowerCase().includes(lowerKeyword)) {
          return { cellElement: cell, rowIndex: i, colIndex: j };
        }
      }
    }
  }
  // Pass 2: Search <td> elements if not found in <th>
  for (let i = 0; i < rows.length; i++) {
    const cells = rows[i].cells;
    for (let j = 0; j < cells.length; j++) {
      const cell = cells[j];
      if (cell.tagName === 'TD') {
        const cellText = getCellText(cell);
        if (cellText.toLowerCase().includes(lowerKeyword)) {
          return { cellElement: cell, rowIndex: i, colIndex: j };
        }
      }
    }
  }
  return null;
}

// Helper to get content from cell above
function getAboveCell(table, rowIndex, colIndex) {
  if (rowIndex > 0 && table.rows[rowIndex - 1] && table.rows[rowIndex - 1].cells[colIndex]) {
    return [getCellText(table.rows[rowIndex - 1].cells[colIndex])];
  }
  return ['']; // Return a single-element array for consistency
}

// Helper to get content from cell(s) below
function getBelowCellOrColumn(table, rowIndex, colIndex, extractType) {
  const result = [];
  if (extractType === "Single Cell") {
    if (rowIndex + 1 < table.rows.length && table.rows[rowIndex + 1] && table.rows[rowIndex + 1].cells[colIndex]) {
      result.push(getCellText(table.rows[rowIndex + 1].cells[colIndex]));
    } else {
      result.push(''); // Push empty if cell doesn't exist
    }
  } else if (extractType === "Entire Column") {
    for (let i = rowIndex + 1; i < table.rows.length; i++) {
      if (table.rows[i] && table.rows[i].cells[colIndex]) {
        result.push(getCellText(table.rows[i].cells[colIndex]));
      } else {
        result.push('');
      }
    }
  }
  // Ensure a single empty string is returned if no data, to represent an empty cell/column
  return result.length > 0 ? result : [''];
}


// Helper to get content from cell(s) to the right
function getRightCellOrRow(table, rowIndex, colIndex, extractType) {
  const result = [];
  const sourceRow = table.rows[rowIndex];
  if (!sourceRow) return [''];

  if (extractType === "Single Cell") {
    if (colIndex + 1 < sourceRow.cells.length && sourceRow.cells[colIndex + 1]) {
      result.push(getCellText(sourceRow.cells[colIndex + 1]));
    } else {
      result.push('');
    }
  } else if (extractType === "Entire Row") {
    for (let i = colIndex + 1; i < sourceRow.cells.length; i++) {
      if (sourceRow.cells[i]) {
        result.push(getCellText(sourceRow.cells[i]));
      } else {
        result.push('');
      }
    }
  }
  return result.length > 0 ? result : [''];
}

// 注入到页面的函数
function extractTableData(tableSelector, keywordSettings, filename, dateFormat, includeHeaders, autoDetect) {
  console.log("Received tableSelector:", tableSelector);
  console.log("Received keywordSettings:", keywordSettings);
  // Other console logs for settings can remain if needed

  let targetTable = null;

  if (tableSelector) {
    targetTable = document.querySelector(tableSelector);
    if (targetTable) {
      console.log("Table found using selector from content script:", targetTable);
      // Send message to content script to clear attribute and highlight
      // This is fire-and-forget from the injected script's perspective.
      chrome.runtime.sendMessage({ action: 'clearTableHighlightAndAttribute' }, response => {
        if (chrome.runtime.lastError) {
            console.warn("Error sending clearTableHighlightAndAttribute message:", chrome.runtime.lastError.message);
        } else if (response && !response.success) {
            console.warn("Failed to clear highlight/attribute:", response.message);
        } else {
            console.log("Table highlight/attribute cleared by content script.");
        }
      });
    } else {
      console.warn(`Table selector "${tableSelector}" provided, but table not found. Falling back.`);
    }
  }

  if (!targetTable) {
    const tables = document.querySelectorAll('table');
    if (tables.length === 0) {
      alert('未找到表格，请确保页面中包含表格元素 (No tables found)');
      return;
    }
    if (tables.length === 1) {
      targetTable = tables[0];
      console.log("Only one table on page, using it.");
    } else {
      console.log("Multiple tables on page or no specific table selected, using findClosestTable.");
      targetTable = findClosestTable(autoDetect);
    }
  }

  if (!targetTable) { // Should be redundant if above logic is sound, but as a safeguard.
    alert('无法确定目标表格 (Could not determine target table).');
    return;
  }
  
  // --- The rest of the extraction logic remains largely the same ---
  let tableData = [];
  const activeKeywords = keywordSettings.filter(ks => ks.keyword && ks.keyword.trim() !== '' && ks.direction !== "None");

  if (activeKeywords.length > 0) {
    console.log("Active keywords found, processing:", activeKeywords);
    let keywordBasedDataFoundAtLeastOnce = false;

    activeKeywords.forEach(setting => {
      const keywordCellInfo = findKeywordCellInfo(targetTable, setting.keyword);

      if (keywordCellInfo) {
        console.log(`Keyword "${setting.keyword}" found at r:${keywordCellInfo.rowIndex}, c:${keywordCellInfo.colIndex}`);
        let extractedValues = [];

        switch (setting.direction) {
          case "Above":
            extractedValues = getAboveCell(targetTable, keywordCellInfo.rowIndex, keywordCellInfo.colIndex);
            break;
          case "Below":
            extractedValues = getBelowCellOrColumn(targetTable, keywordCellInfo.rowIndex, keywordCellInfo.colIndex, setting.extractBelow);
            break;
          case "Right":
            extractedValues = getRightCellOrRow(targetTable, keywordCellInfo.rowIndex, keywordCellInfo.colIndex, setting.extractRight);
            break;
        }

        // Check if extractedValues actually contains meaningful data (not just a single empty string)
        if (extractedValues.length > 0 && (extractedValues.length > 1 || extractedValues[0] !== '')) {
          keywordBasedDataFoundAtLeastOnce = true;
          if (setting.direction === "Below" && setting.extractBelow === "Entire Column") {
            extractedValues.forEach(value => {
                tableData.push([setting.keyword, value]);
            });
          } else if (setting.direction === "Right" && setting.extractRight === "Entire Row") {
            tableData.push([setting.keyword, ...extractedValues]);
          } else {
            tableData.push([setting.keyword, ...extractedValues]);
          }
        } else {
           // Keyword found, but no data extracted (e.g. cell above was empty, or end of table)
           console.log(`Keyword "${setting.keyword}" processed, but no data extracted for direction "${setting.direction}".`);
           tableData.push([setting.keyword, '']); // Add keyword with an empty value
           keywordBasedDataFoundAtLeastOnce = true; // Still counts as "found" for fallback logic
        }
      } else {
        console.log(`Keyword "${setting.keyword}" not found in table.`);
        tableData.push([setting.keyword, "KEYWORD_NOT_FOUND"]);
      }
    });

    if (!keywordBasedDataFoundAtLeastOnce && activeKeywords.length > 0) {
      // This case means keywords were active, but NONE of them were found or yielded data.
      // The user might want to know this, instead of a full table dump.
      // However, current spec is to fallback.
      console.log("No active keywords led to data extraction. Falling back to full table extraction.");
      tableData = extractTableContent(targetTable, includeHeaders);
    } else if (!keywordBasedDataFoundAtLeastOnce && activeKeywords.length === 0) {
      // No active keywords to begin with
      console.log("No active keywords. Falling back to full table extraction.");
      tableData = extractTableContent(targetTable, includeHeaders);
    }
    // If keywordBasedDataFoundAtLeastOnce is true, tableData will contain the keyword results.

  } else {
    console.log("No active keywords defined. Falling back to full table extraction.");
    tableData = extractTableContent(targetTable, includeHeaders);
  }
  
  if (tableData.length === 0) {
    // If after all processing, tableData is empty (e.g. keywords found no data, and fallback was also empty)
    alert('No data extracted. The table might be empty or keywords did not yield results.');
    return;
  }

  const csvContent = convertToCSV(tableData);
  
  // Construct filename based on settings
  let fullFilename = filename;
  if (dateFormat) {
    const date = new Date();
    const formattedDate = `${date.getFullYear()}-${(date.getMonth() + 1).toString().padStart(2, '0')}-${date.getDate().toString().padStart(2, '0')}_${date.getHours().toString().padStart(2, '0')}-${date.getMinutes().toString().padStart(2, '0')}`;
    fullFilename += `_${formattedDate}`;
  }
  fullFilename += '.csv';

  // 下载文件
  downloadCSV(csvContent, fullFilename);
}

// Modified to accept includeHeaders, though not fully implemented in this version of extractTableContent
function findClosestTable(autoDetectEnabled = true) { // Added autoDetectEnabled, not fully used yet
  const tables = document.querySelectorAll('table');
  // 简单实现：返回第一个可见的表格
  for (let table of tables) {
    const rect = table.getBoundingClientRect();
    if (rect.width > 0 && rect.height > 0) {
      return table;
    }
  }
  return tables[0];
}

function extractTableContent(table, includeHeaders) {
  const rows = [];
  // Determine which rows to select (all, or skip header if !includeHeaders)
  // This is a simplified version; proper header skipping might need more context
  const tableRows = table.querySelectorAll('tr');
  
  let isFirstRow = true;
  tableRows.forEach(row => {
    // Basic header skipping logic - might need refinement
    if (!includeHeaders && isFirstRow && row.querySelectorAll('th').length > 0) {
        isFirstRow = false;
        return; // Skip header row if includeHeaders is false and it looks like a header
    }
    isFirstRow = false;

    const cells = [];
    // If includeHeaders is true, get th and td. If false, ideally only td, but current selector gets both.
    const tableCells = row.querySelectorAll('td, th');
    
    tableCells.forEach(cell => {
      // 清理文本内容
      let text = cell.textContent || cell.innerText || '';
      text = text.trim().replace(/\s+/g, ' ');
      cells.push(text);
    });
    
    if (cells.length > 0) {
      rows.push(cells);
    }
  });
  
  return rows;
}

// 将数据转换为CSV格式
function convertToCSV(data, fileFormat) {
    // 注意：此函数主要用于旧的表格和关键词提取逻辑
    // 新的文本提取 (contentExtracted) 有自己的 convertTextToCsvFormat
    if (fileFormat === 'txt') {
        if (Array.isArray(data) && data.length > 0 && Array.isArray(data[0])) {
            return data.map(row => row.join('\t')).join('\n');
        } else if (typeof data === 'string') {
            return data;
        }
        return '';
    }
    if (typeof data === 'string') {
        // 对于旧的 extractText (选中文本)，我们可能也希望简单处理
        return '"' + data.replace(/"/g, '""') + '"'; // 包装并转义
    }
    try {
        return Papa.unparse(data); // 用于表格数据
    } catch (e) {
        console.error("Error parsing data to CSV with PapaParse: ", e);
        if (Array.isArray(data)) {
            return data.map(row => {
                if (Array.isArray(row)) {
                    return row.map(cell => '"' + String(cell).replace(/"/g, '""') + '"').join(',');
                }
                return '"' + String(row).replace(/"/g, '""') + '"';
            }).join('\n');
        }
        return '';
    }
}

// 下载CSV文件（增强版本，支持BOM头和错误处理）
function downloadCSV(csvData, filename) {
    try {
        // 确保 BOM 只在必要时添加，并且 csvData 是字符串
        const finalCsvData = typeof csvData === 'string' ? csvData : Papa.unparse(csvData);
        const blob = new Blob(["\uFEFF" + finalCsvData], { type: 'text/csv;charset=utf-8;' });

        // 使用 FileReader 将 Blob 转换为 data URL
        const reader = new FileReader();
        reader.onload = function(event) {
            const dataUrl = event.target.result;
            chrome.downloads.download({
                url: dataUrl,
                filename: filename,
                saveAs: true
            }, (downloadId) => {
                if (chrome.runtime.lastError) {
                    console.error(`CSV Download failed for ${filename}: ${chrome.runtime.lastError.message}`);
                    showNotification('下载失败', `CSV文件下载失败: ${filename}`);
                } else {
                    console.log(`CSV Download started for ${filename} with ID: ${downloadId}`);
                    showNotification('下载成功', `CSV文件已保存: ${filename}`);
                }
                // dataUrl 不需要 revokeObjectURL
            });
        };
        reader.onerror = function(event) {
            console.error("File reading error for CSV download:", event.target.error);
            showNotification('下载失败', '文件处理失败，请重试');
        };
        reader.readAsDataURL(blob);
    } catch (error) {
        console.error('Error downloading CSV:', error);
        showNotification('下载失败', '数据处理失败: ' + error.message);
    }
}

// 通知函数
function showNotification(title, message) {
  chrome.notifications.create({
    type: 'basic',
    iconUrl: 'icons/icon48.png',
    title: title,
    message: message
  });
}

// PDF并发下载控制函数
async function downloadPDFsWithConcurrencyControl(pdfLinks, timestamp) {
  const MAX_CONCURRENT = 3; // 最大并发下载数
  let activeDownloads = 0;
  let downloadQueue = [...new Set(pdfLinks)]; // 去重
  let completedCount = 0;
  
  async function downloadNext() {
    if (downloadQueue.length === 0 || activeDownloads >= MAX_CONCURRENT) {
      return;
    }
    
    const link = downloadQueue.shift();
    activeDownloads++;
    
    try {
      let pdfFilename = link.substring(link.lastIndexOf('/') + 1);
      if (!pdfFilename.toLowerCase().endsWith('.pdf')) {
        pdfFilename += '.pdf';
      }
      pdfFilename = pdfFilename.replace(/[^a-zA-Z0-9._-]/g, '_'); // 清理文件名
      if (pdfFilename.length > 100) pdfFilename = pdfFilename.substring(0, 95) + '.pdf';
      
      chrome.downloads.download({
        url: link,
        filename: `${timestamp}_${pdfFilename}`,
        saveAs: false
      }, (downloadId) => {
        activeDownloads--;
        completedCount++;
        
        if (chrome.runtime.lastError) {
          console.error(`PDF下载失败 ${link}:`, chrome.runtime.lastError.message);
          // 重试逻辑
          setTimeout(() => {
            chrome.downloads.download({ url: link }, (retryId) => {
              if (chrome.runtime.lastError) {
                showNotification('PDF下载失败', `无法下载: ${link}`);
              } else {
                showNotification('PDF重试成功', `重新下载: ${pdfFilename}`);
              }
            });
          }, 2000);
        } else {
          console.log(`PDF下载开始: ${pdfFilename} (ID: ${downloadId})`);
        }
        
        // 继续下载队列中的下一个
        downloadNext();
        
        // 所有下载完成时的通知
        if (completedCount === pdfLinks.length) {
          showNotification('下载完成', `已处理 ${pdfLinks.length} 个PDF文件`);
        }
      });
    } catch (error) {
      activeDownloads--;
      console.error('PDF下载错误:', error);
      downloadNext();
    }
  }
  
  // 启动初始下载
  for (let i = 0; i < Math.min(MAX_CONCURRENT, downloadQueue.length); i++) {
    downloadNext();
  }
}

// Helper function to escape text for CSV cells
function escapeCsvCell(cellText) {
  if (cellText.includes(',') || cellText.includes('"') || cellText.includes('\n')) {
    // Replace any existing double quotes with two double quotes
    const escapedText = cellText.replace(/"/g, '""');
    // Enclose the entire string in double quotes
    return `"${escapedText}"`;
  }
  return cellText;
}

// 监听来自 content script 的消息
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "keywordDataExtracted") {
        const csvData = convertToCSV(request.data, request.fileFormat);
        downloadCSV(csvData, `keyword_extract.${request.fileFormat}`);
    } else if (request.action === "tableDataExtracted") {
        const csvData = convertToCSV(request.data, request.fileFormat);
        downloadCSV(csvData, `table_extract.${request.fileFormat}`);
    } else if (request.action === "openOptionsPage") {
        chrome.runtime.openOptionsPage();
    } else if (request.action === "getTableData") {
        if (sender.tab && sender.tab.id) {
            chrome.storage.sync.get(['fileFormat', 'tableDetection'], (settings) => {
                extractTableDataFromPage(sender.tab.id, settings, request.tableSelector, sendResponse);
            });
        } else {
            console.error("Sender tab ID not found for getTableData action.");
            sendResponse({ success: false, error: "Sender tab ID not found." });
        }
        return true; // Indicates that the response will be sent asynchronously
    } else if (request.action === "contentExtracted") {
        // 处理从 content.js 发送过来的文本和PDF链接
        if (request.text) {
            const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
            const filename = request.source === 'keywords' ? `extracted_by_keywords_${timestamp}.csv` : `full_page_text_${timestamp}.csv`;
            const csvContent = convertTextToCsvFormat(request.text, request.source); // 传递 source 以便更好格式化
            downloadCSV(csvContent, filename);
        }
        if (request.pdfLinks && request.pdfLinks.length > 0) {
            const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
            downloadPDFsWithConcurrencyControl(request.pdfLinks, timestamp);
        }
        sendResponse({ success: true, message: "Data received and processing started." });
    }
});

// 将文本转换为CSV格式的辅助函数（增强版本）
function convertTextToCsvFormat(text, source) {
    if (!text || typeof text !== 'string') {
        return 'No content available';
    }
    
    // 根据来源进行不同的格式化
    if (source === 'keywords') {
        // 关键词提取的文本，按行处理
        const lines = text.split('\n').filter(line => line.trim());
        return lines.map(line => {
            // 替换逗号防止CSV格式错误，清理文本
            const cleanLine = line.trim().replace(/,/g, '，').replace(/"/g, '""');
            return `"${cleanLine}"`;
        }).join(',');
    } else {
        // 全文提取，简单处理
        const cleanText = text.replace(/\s+/g, ' ').replace(/,/g, '，').trim();
        return `"${cleanText.replace(/"/g, '""')}"`;
    }
}

// REMOVE THE DUPLICATE LISTENER BELOW
/*
// Listener for context menu clicks
chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId === "highlightAndSaveTable") {
    chrome.tabs.sendMessage(tab.id, { action: "highlightTable" }, (response) => {
      if (chrome.runtime.lastError) {
        console.error(chrome.runtime.lastError.message);
        return;
      }
      if (response && response.tableData) {
        const csvData = Papa.unparse(response.tableData);
        const blob = new Blob([csvData], { type: 'text/csv;charset=utf-8;' });
        const url = URL.createObjectURL(blob);
        chrome.downloads.download({
          url: url,
          filename: 'table_export.csv',
          saveAs: true
        });
      } else {
        console.log("No table data received or no table highlighted.");
      }
    });
  } else if (info.menuItemId === "extractByKeywordsToCsv" || info.menuItemId === "copyFullTextToCsv") {
    const action = info.menuItemId === "extractByKeywordsToCsv" ? "extractByKeywordsAndDownloadPdfs" : "copyFullTextAndDownloadPdfs";
    chrome.tabs.sendMessage(tab.id, { action: action }, (response) => {
      if (chrome.runtime.lastError) {
        console.error("Error sending message to content script:", chrome.runtime.lastError.message);
        return;
      }
      if (response && response.text) {
        // Create and download CSV
        const csvText = response.text; // Assuming text is already formatted or is just a block of text
        // If it needs to be a proper CSV row/column, adjust this part.
        // For now, we'll save the raw text as a CSV.
        const blob = new Blob(["\uFEFF" + csvText], { type: 'text/csv;charset=utf-8;' }); // Added BOM for Excel
        const url = URL.createObjectURL(blob);
        const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
        const csvFilename = `page_content_${timestamp}.csv`;
        chrome.downloads.download({
          url: url,
          filename: csvFilename,
          saveAs: true
        });

        // Download PDFs
        if (response.pdfLinks && response.pdfLinks.length > 0) {
          response.pdfLinks.forEach(pdfLink => {
            // Try to derive a filename from the URL
            let filename = pdfLink.substring(pdfLink.lastIndexOf('/') + 1);
            if (!filename.toLowerCase().endsWith('.pdf')) {
                filename += '.pdf';
            }
            // Sanitize filename (basic example)
            filename = filename.replace(/[^a-zA-Z0-9._-]/g, '_');
            if (filename.length > 100) filename = filename.substring(0, 100) + '.pdf'; // Truncate long names

            chrome.downloads.download({
              url: pdfLink,
              filename: filename, // Suggests a filename, user can change
              // saveAs: true // Optional: set to true if you want saveAs dialog for each PDF
            }, (downloadId) => {
              if (chrome.runtime.lastError) {
                console.error(`Download failed for ${pdfLink}: ${chrome.runtime.lastError.message}`);
              } else {
                console.log(`Download started for ${pdfLink} with ID: ${downloadId}`);
              }
            });
          });
        }
      } else {
        console.log("No text or PDF links received from content script.");
      }
    });
  }
});
*/
// ... existing code ...