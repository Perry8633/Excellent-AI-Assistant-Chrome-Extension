// 内容脚本，负责页面内容提取、PDF查找、与后台通信
function getKeywordsAndHeaders() {
  return new Promise(resolve => {
    chrome.storage.local.get(['csvHeaders'], (result) => {
      resolve(result.csvHeaders || []);
    });
  });
}

function extractByKeywords(text, headers) {
  // headers: ["关键词1", "关键词2", ...]
  const rows = [];
  for (let i = 0; i < headers.length - 1; i++) {
    const start = text.indexOf(headers[i]);
    const end = text.indexOf(headers[i+1]);
    if (start !== -1 && end !== -1 && end > start) {
      rows.push(text.substring(start + headers[i].length, end).trim());
    } else {
      rows.push('');
    }
  }
  // 最后一段
  if (headers.length > 1) {
    const last = text.indexOf(headers[headers.length-1]);
    if (last !== -1) {
      rows.push(text.substring(last + headers[headers.length-1].length).trim());
    } else {
      rows.push('');
    }
  }
  return rows;
}

function toCSV(headers, row) {
  return headers.join(',') + '\n' + row.map(cell => '"'+cell.replace(/"/g,'""')+'"').join(',') + '\n';
}

function findPDFLinks() {
  const links = Array.from(document.querySelectorAll('a[href]'));
  return links.map(a => a.href).filter(href => href.endsWith('.pdf') || href.startsWith('https://idrive.zte.com.cn/zte-km-clouddudm-clouddisk/objects/downloadByToken/'));
}

chrome.runtime.onMessage.addListener(async (msg, sender, sendResponse) => {
  if (msg.action === 'extract_to_csv') {
    const headers = await getKeywordsAndHeaders();
    const row = extractByKeywords(msg.selectionText || window.getSelection().toString(), headers);
    const csv = toCSV(headers, row);
    chrome.runtime.sendMessage({ action: 'download_csv', csv, filename: 'extracted.csv' });
  }
  if (msg.action === 'save_page_csv_pdf') {
    const headers = await getKeywordsAndHeaders();
    const text = document.body.innerText;
    const row = extractByKeywords(text, headers);
    const csv = toCSV(headers, row);
    const pdfLinks = findPDFLinks();
    chrome.runtime.sendMessage({ action: 'download_csv', csv, filename: 'page.csv' });
    chrome.runtime.sendMessage({ action: 'download_pdfs', pdfLinks });
  }
});
