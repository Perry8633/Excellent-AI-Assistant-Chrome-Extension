// options.js 负责设置页逻辑，强制只能通过关闭按钮关闭
const headersInput = document.getElementById('headers');
const saveBtn = document.getElementById('save');
const historySel = document.getElementById('history');
const closeBtn = document.getElementById('closeBtn');

function renderHistory(list) {
  historySel.innerHTML = '';
  list.forEach((item, idx) => {
    const opt = document.createElement('option');
    opt.value = item.join(',');
    opt.textContent = item.join(',');
    historySel.appendChild(opt);
  });
}

chrome.storage.local.get(['csvHeaders', 'headersHistory'], (result) => {
  if (result.csvHeaders) headersInput.value = result.csvHeaders.join(',');
  renderHistory(result.headersHistory || []);
});

saveBtn.onclick = () => {
  const headers = headersInput.value.split(',').map(s => s.trim()).filter(Boolean);
  if (!headers.length) return alert('请输入表头');
  chrome.storage.local.set({ csvHeaders: headers }, () => alert('已保存'));
};

historySel.onchange = () => {
  headersInput.value = historySel.value;
  chrome.storage.local.set({ csvHeaders: historySel.value.split(',') });
};

closeBtn.onclick = () => {
  window.close();
};

// 禁止通过ESC、窗口X按钮关闭
window.onbeforeunload = (e) => {
  e.preventDefault();
  return '';
};
window.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') e.preventDefault();
});
