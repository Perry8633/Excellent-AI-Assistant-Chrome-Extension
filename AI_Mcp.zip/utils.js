// utils.js 可选：可扩展更多工具函数
// 目前核心逻辑已在 content.js 实现，如需更复杂的 CSV/PDF 处理可在此扩展
