// 后台脚本，负责右键菜单、消息通信、下载逻辑
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: 'export_page_data',
    title: '导出页面数据',
    contexts: ['all']
  });
  chrome.contextMenus.create({
    id: 'extract_to_csv',
    parentId: 'export_page_data',
    title: '按关键词提取到 CSV',
    contexts: ['all']
  });
  chrome.contextMenus.create({
    id: 'save_page_csv_pdf',
    parentId: 'export_page_data',
    title: '保存整个页面为 CSV 并下载PDF',
    contexts: ['all']
  });
});

chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (info.menuItemId === 'extract_to_csv') {
    chrome.tabs.sendMessage(tab.id, { action: 'extract_to_csv', selectionText: info.selectionText });
  } else if (info.menuItemId === 'save_page_csv_pdf') {
    chrome.tabs.sendMessage(tab.id, { action: 'save_page_csv_pdf' });
  }
});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.action === 'download_csv') {
    const url = URL.createObjectURL(new Blob([msg.csv], { type: 'text/csv' }));
    chrome.downloads.download({ url, filename: msg.filename, saveAs: true });
  }
  if (msg.action === 'download_pdfs') {
    (msg.pdfLinks || []).forEach((link, idx) => {
      chrome.downloads.download({ url: link, filename: `pdf_${idx+1}.pdf`, saveAs: false });
    });
  }
});
