// popup.js 负责表头配置、历史管理、跳转设置页
const headersInput = document.getElementById('headers');
const saveBtn = document.getElementById('save');
const historyDiv = document.getElementById('history');
const toOptionsBtn = document.getElementById('toOptions');

function renderHistory(list) {
  historyDiv.innerHTML = '<b>历史表头：</b>';
  list.forEach((item, idx) => {
    const div = document.createElement('div');
    div.className = 'history-item';
    div.textContent = item.join(',');
    div.onclick = () => {
      headersInput.value = item.join(',');
      chrome.storage.local.set({ csvHeaders: item });
    };
    historyDiv.appendChild(div);
  });
}

chrome.storage.local.get(['csvHeaders', 'headersHistory'], (result) => {
  if (result.csvHeaders) headersInput.value = result.csvHeaders.join(',');
  renderHistory(result.headersHistory || []);
});

saveBtn.onclick = () => {
  const headers = headersInput.value.split(',').map(s => s.trim()).filter(Boolean);
  if (!headers.length) return alert('请输入表头');
  chrome.storage.local.set({ csvHeaders: headers }, () => {
    chrome.storage.local.get(['headersHistory'], (result) => {
      let history = result.headersHistory || [];
      if (!history.some(h => h.join(',') === headers.join(','))) {
        history.unshift(headers);
        if (history.length > 10) history = history.slice(0, 10);
        chrome.storage.local.set({ headersHistory: history }, () => renderHistory(history));
      }
    });
  });
};

toOptionsBtn.onclick = () => {
  chrome.runtime.openOptionsPage();
};
