// 存储工具函数
const StorageUtils = {
  // 保存配置
  async saveConfig(config) {
    try {
      await chrome.storage.sync.set({ formFields: config });
      return { success: true };
    } catch (error) {
      return { success: false, error: error.message };
    }
  },

  // 加载配置
  async loadConfig() {
    try {
      const result = await chrome.storage.sync.get('formFields');
      return { success: true, data: result.formFields || [] };
    } catch (error) {
      return { success: false, error: error.message };
    }
  },

  // 清除配置
  async clearConfig() {
    try {
      await chrome.storage.sync.remove('formFields');
      return { success: true };
    } catch (error) {
      return { success: false, error: error.message };
    }
  }
};