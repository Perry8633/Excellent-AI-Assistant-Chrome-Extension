document.addEventListener('DOMContentLoaded', () => {
  const fieldsContainer = document.getElementById('fields-container');
  const addFieldBtn = document.getElementById('add-field');
  const saveConfigBtn = document.getElementById('save-config');
  const statusEl = document.getElementById('status');
  
  let fieldIndex = 2; // 从2开始，因为已有两个默认字段

  // 加载现有配置
  loadConfig();

  addFieldBtn.addEventListener('click', addField);
  saveConfigBtn.addEventListener('click', saveConfig);
  fieldsContainer.addEventListener('click', handleFieldActions);

  function addField() {
    const fieldItem = document.createElement('div');
    fieldItem.className = 'field-item';
    fieldItem.innerHTML = `
      <label for="field-name-${fieldIndex}">字段名称:</label>
      <input type="text" id="field-name-${fieldIndex}" class="field-name" value="">
      <label for="field-selectors-${fieldIndex}">选择器 (用逗号分隔):</label>
      <input type="text" id="field-selectors-${fieldIndex}" class="field-selectors" value="">
      <button class="remove-field">删除</button>
    `;
    fieldsContainer.appendChild(fieldItem);
    fieldIndex++;
  }

  function handleFieldActions(event) {
    if (event.target.classList.contains('remove-field')) {
      event.target.parentElement.remove();
    }
  }

  async function saveConfig() {
    const fieldItems = document.querySelectorAll('.field-item');
    const fields = [];
    
    fieldItems.forEach(item => {
      const name = item.querySelector('.field-name').value.trim();
      const selectorsText = item.querySelector('.field-selectors').value.trim();
      
      if (name && selectorsText) {
        const selectors = selectorsText.split(',').map(s => s.trim()).filter(s => s);
        fields.push({ name, selectors });
      }
    });
    
    try {
      await chrome.storage.sync.set({ formFields: fields });
      statusEl.textContent = '配置保存成功！';
      statusEl.style.color = 'green';
    } catch (error) {
      statusEl.textContent = '保存失败: ' + error.message;
      statusEl.style.color = 'red';
    }
  }

  async function loadConfig() {
    try {
      const result = await chrome.storage.sync.get('formFields');
      if (result.formFields && result.formFields.length > 0) {
        // 清空现有字段
        fieldsContainer.innerHTML = '';
        fieldIndex = 0;
        
        // 加载保存的字段
        result.formFields.forEach(field => {
          const fieldItem = document.createElement('div');
          fieldItem.className = 'field-item';
          fieldItem.innerHTML = `
            <label for="field-name-${fieldIndex}">字段名称:</label>
            <input type="text" id="field-name-${fieldIndex}" class="field-name" value="${field.name}">
            <label for="field-selectors-${fieldIndex}">选择器 (用逗号分隔):</label>
            <input type="text" id="field-selectors-${fieldIndex}" class="field-selectors" value="${field.selectors.join(',')}">
            <button class="remove-field">删除</button>
          `;
          fieldsContainer.appendChild(fieldItem);
          fieldIndex++;
        });
      }
    } catch (error) {
      console.error('加载配置失败:', error);
    }
  }
});