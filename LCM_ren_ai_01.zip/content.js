chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "exportData") {
    getFormFields().then(fields => {
      const data = extractFormValues(fields);
      sendResponse({data});
    }).catch(error => {
      sendResponse({error: error.message});
      console.error(error);
    });
    return true; // 保持消息通道打开
  }
});

async function getFormFields() {
  // 优先使用用户自定义字段配置
  const config = await chrome.storage.sync.get('formFields');
  if (config.formFields && config.formFields.length > 0) {
    return config.formFields;
  }

  //  fallback to default fields
  return [
    {name: "受限制主体编号", selectors: ["[id*='number']", "[name*='code']"]},
    {name: "名称", selectors: ["[id*='name']", "[name*='title']"]},
    {name: "国家/地区", selectors: ["[id*='country']", "[name*='region']"]},
    {name: "城市", selectors: ["[id*='city']", "[name*='city']"]},
    {name: "详细地址", selectors: ["[id*='address']", "[name*='addr']"]},
    {name: "邮编", selectors: ["[id*='postcode']", "[name*='zip']"]},
    {name: "备注", selectors: ["[id*='remark']", "[name*='note']", "textarea"]}
  ];
}

function extractFormValues(fields) {
  const data = {};
  fields.forEach(field => {
    const element = findFormElement(field.selectors, field.name);
    data[field.name] = element ? getElementValue(element).trim() : "";
  });
  return data;
}