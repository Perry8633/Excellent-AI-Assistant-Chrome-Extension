// 用户通知函数
function notifyUser(title, message) {
  chrome.notifications.create({
    type: 'basic',
    iconUrl: 'icons/icon48.png', // 确保图标路径正确
    title: title,
    message: message,
    priority: 2
  });
}

// 下载CSV文件的函数
function downloadCSV(csvContent, filenamePrefix) {
  const blob = new Blob(["\uFEFF" + csvContent], { type: 'text/csv;charset=utf-8;' }); // 添加 BOM 头确保UTF-8编码被正确识别
  const url = URL.createObjectURL(blob);
  const now = new Date();
  const timestamp = `${now.getFullYear()}${(now.getMonth() + 1).toString().padStart(2, '0')}${now.getDate().toString().padStart(2, '0')}_${now.getHours().toString().padStart(2, '0')}${now.getMinutes().toString().padStart(2, '0')}${now.getSeconds().toString().padStart(2, '0')}`;
  
  // 从存储中获取文件名模板
  chrome.storage.sync.get(['settings'], (result) => {
    const settings = result.settings || {};
    let filename = settings.fileNameTemplate || '[filenamePrefix]_[timestamp].csv';
    filename = filename.replace('[filenamePrefix]', filenamePrefix)
                       .replace('[timestamp]', timestamp)
                       .replace('[date]', `${now.getFullYear()}${(now.getMonth() + 1).toString().padStart(2, '0')}${now.getDate().toString().padStart(2, '0')}`)
                       .replace('[time]', `${now.getHours().toString().padStart(2, '0')}${now.getMinutes().toString().padStart(2, '0')}${now.getSeconds().toString().padStart(2, '0')}`);
    
    if (!filename.toLowerCase().endsWith('.csv')) {
        filename += '.csv';
    }

    chrome.downloads.download({
      url: url,
      filename: filename,
      saveAs: !(settings.autoSave || false) // 如果autoSave为true，则不显示另存为对话框
    }, (downloadId) => {
      if (chrome.runtime.lastError) {
        console.error("Download failed:", chrome.runtime.lastError.message);
        notifyUser("下载失败", `无法下载文件：${chrome.runtime.lastError.message}`);
      } else {
        console.log("Download started with ID:", downloadId);
      }
      // 无论下载成功或失败，都尝试释放 Object URL
      setTimeout(() => URL.revokeObjectURL(url), 10000); // 延迟释放以确保下载完成
    });
  });
}

// 发送消息到内容脚本，带重试机制
function sendMessageToContentScript(tabId, message, callback) {
  let retries = 3;
  function attemptSend() {
    chrome.tabs.sendMessage(tabId, message, (response) => {
      if (chrome.runtime.lastError) {
        console.warn(`Send message attempt failed: ${chrome.runtime.lastError.message}. Retries left: ${retries}`);
        if (retries > 0) {
          retries--;
          setTimeout(attemptSend, 500); // 稍作等待后重试
        } else {
          if (callback) callback({ error: `无法连接到内容脚本: ${chrome.runtime.lastError.message}` });
        }
      } else {
        if (callback) callback(response);
      }
    });
  }
  attemptSend();
}

// 创建右键菜单
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: "exportTable",
    title: "导出选中表格为CSV",
    contexts: ["selection"]
  });
  chrome.contextMenus.create({
    id: "exportVisibleTable",
    title: "导出页面可见表格为CSV",
    contexts: ["page"]
  });
  chrome.contextMenus.create({
    id: "exportAllForms",
    title: "导出页面所有表单数据",
    contexts: ["page"]
  });
});

// 监听右键菜单点击事件
chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (!tab || !tab.id) {
    console.error("Tab ID not found.");
    notifyUser("错误", "无法获取当前标签页信息。");
    return;
  }
  if (info.menuItemId === "exportTable") {
    sendMessageToContentScript(tab.id, { action: "getSelectedTableData" }, (response) => {
      if (chrome.runtime.lastError) {
        console.error("Error sending message to content script for getSelectedTableData:", chrome.runtime.lastError.message);
        notifyUser("错误", "无法与页面内容脚本通信，请刷新页面后重试。");
        return;
      }
      if (response && response.csvData) {
        downloadCSV(response.csvData, response.filenamePrefix || "selected_table_data");
      } else if (response && response.error) {
        notifyUser("导出失败", response.error);
      } else {
        notifyUser("导出失败", "未能从选区获取表格数据。");
      }
    });
  } else if (info.menuItemId === "exportVisibleTable") {
    sendMessageToContentScript(tab.id, { action: "getVisibleTableData" }, (response) => {
      if (chrome.runtime.lastError) {
        console.error("Error sending message to content script for getVisibleTableData:", chrome.runtime.lastError.message);
        notifyUser("错误", "无法与页面内容脚本通信，请刷新页面后重试。");
        return;
      }
      if (response && response.csvData) {
        downloadCSV(response.csvData, response.filenamePrefix || "visible_table_data");
      } else if (response && response.error) {
        notifyUser("导出失败", response.error);
      } else {
        notifyUser("导出失败", "未能获取页面上的可见表格数据。");
      }
    });
  } else if (info.menuItemId === "exportAllForms") {
    sendMessageToContentScript(tab.id, { action: "getAllFormData" }, (response) => {
      if (chrome.runtime.lastError) {
        console.error("Error sending message to content script for getAllFormData:", chrome.runtime.lastError.message);
        notifyUser("错误", "无法与页面内容脚本通信，请刷新页面后重试。");
        return;
      }
      if (response && response.csvData) {
        downloadCSV(response.csvData, response.filenamePrefix || "all_form_data");
      } else if (response && response.error) {
        notifyUser("导出失败", response.error);
      } else {
        notifyUser("导出失败", "未能获取页面上的表单数据。");
      }
    });
  }
});

// 监听来自内容脚本或其他部分的消息 (如果需要)
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "downloadCSV") { // 示例：如果内容脚本请求下载
    if (request.csvData) {
      downloadCSV(request.csvData, request.filenamePrefix || "exported_data");
      sendResponse({ success: true, message: "CSV下载已开始。" });
    } else {
      sendResponse({ success: false, error: "没有提供CSV数据。" });
      notifyUser("下载错误", "未能生成CSV文件，数据为空。");
    }
    return true; // 异步响应
  }
});

console.log("Background script loaded.");