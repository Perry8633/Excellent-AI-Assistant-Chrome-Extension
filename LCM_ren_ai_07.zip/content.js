console.log("Content script loaded and running.");

// 辅助函数：清理和转义CSV单元格内容
function sanitizeCSVCell(text) {
  if (text === null || typeof text === 'undefined') {
    return '';
  }
  let str = String(text).trim();
  str = str.replace(/"/g, '""'); // 替换双引号为两个双引号
  // 如果包含逗号、换行符或双引号，则用双引号包裹起来
  if (str.includes(',') || str.includes('\n') || str.includes('"')) {
    str = `"${str}"`;
  }
  return str;
}

// 辅助函数：将二维数组转换为CSV字符串
function arrayToCSV(dataArray) {
  if (!dataArray || dataArray.length === 0) {
    return '';
  }
  return dataArray.map(row => 
    row.map(cell => sanitizeCSVCell(cell)).join(',')
  ).join('\n');
}

// 辅助函数：从HTML元素中提取文本，尝试处理隐藏元素和输入字段
function getTextFromElement(element) {
    if (!element) return '';
    if (element.tagName === 'INPUT' || element.tagName === 'TEXTAREA' || element.tagName === 'SELECT') {
        return element.value || '';
    }
    let text = element.innerText || element.textContent || '';
    return text.replace(/\s+/g, ' ').trim();
}

// 核心函数：处理单个表格元素，提取数据（包括表头和合并单元格）
function processTableToCSVData(tableElement) {
  const data = [];
  const tempGrid = []; // 用于处理 rowspan 和 colspan

  // 1. 提取表头 (thead, tfoot 作为表头的一部分)
  const headerSections = Array.from(tableElement.querySelectorAll('thead, tfoot'));
  if (tableElement.tHead) headerSections.unshift(tableElement.tHead); // 确保thead优先
  
  let headerRowsCount = 0;
  headerSections.forEach(section => {
      Array.from(section.rows).forEach((row, rowIndexInHeader) => {
          const absoluteRowIndex = headerRowsCount + rowIndexInHeader;
          const rowData = [];
          let gridColIndex = 0;
          Array.from(row.cells).forEach((cell) => {
              while (tempGrid[absoluteRowIndex] && tempGrid[absoluteRowIndex][gridColIndex]) {
                  gridColIndex++;
              }
              const cellText = getTextFromElement(cell);
              rowData[gridColIndex] = cellText;

              const colspan = parseInt(cell.getAttribute('colspan') || '1', 10);
              const rowspan = parseInt(cell.getAttribute('rowspan') || '1', 10);

              for (let r = 0; r < rowspan; r++) {
                  if (!tempGrid[absoluteRowIndex + r]) tempGrid[absoluteRowIndex + r] = [];
                  for (let c = 0; c < colspan; c++) {
                      tempGrid[absoluteRowIndex + r][gridColIndex + c] = cellText; 
                  }
              }
              gridColIndex += colspan;
          });
          data.push(rowData.map(cell => cell || ''));
      });
      headerRowsCount += section.rows.length;
  });

  // 2. 提取表格主体 (tbody)
  const bodies = Array.from(tableElement.tBodies);
  if (bodies.length === 0 && tableElement.rows.length > headerRowsCount) {
      // 如果没有tbody，但table有除了表头之外的行，则将这些行视为一个tbody
      const implicitBody = document.createElement('tbody');
      for(let i = headerRowsCount; i < tableElement.rows.length; i++){
          implicitBody.appendChild(tableElement.rows[i].cloneNode(true));
      }
      if(implicitBody.rows.length > 0) bodies.push(implicitBody);
  }
  
  // 如果在thead/tfoot后仍未提取到任何行，并且表格本身有行，尝试将第一行作为表头
  if (data.length === 0 && tableElement.rows.length > 0 && bodies.length === 0) {
    const firstRow = tableElement.rows[0];
    const rowData = [];
    Array.from(firstRow.cells).forEach(cell => {
        rowData.push(getTextFromElement(cell));
    });
    data.push(rowData.map(cell => cell || ''));
    headerRowsCount = 1; // 标记已处理表头
    // 更新tempGrid以反映这个隐式表头
    if (!tempGrid[0]) tempGrid[0] = [];
    rowData.forEach((_, idx) => tempGrid[0][idx] = true);

    // 将剩余行加入bodies进行处理
    const implicitBody = document.createElement('tbody');
    for(let i = 1; i < tableElement.rows.length; i++){
        implicitBody.appendChild(tableElement.rows[i].cloneNode(true));
    }
    if(implicitBody.rows.length > 0) bodies.push(implicitBody);
  }

  bodies.forEach(body => {
    Array.from(body.rows).forEach((row) => {
      const currentRowIndexInGrid = data.length;
      const rowData = [];
      let gridColIndex = 0;

      Array.from(row.cells).forEach((cell) => {
        while (tempGrid[currentRowIndexInGrid] && tempGrid[currentRowIndexInGrid][gridColIndex]) {
          gridColIndex++;
        }
        const cellText = getTextFromElement(cell);
        rowData[gridColIndex] = cellText;

        const colspan = parseInt(cell.getAttribute('colspan') || '1', 10);
        const rowspan = parseInt(cell.getAttribute('rowspan') || '1', 10);

        for (let r = 0; r < rowspan; r++) {
          if (!tempGrid[currentRowIndexInGrid + r]) tempGrid[currentRowIndexInGrid + r] = [];
          for (let c = 0; c < colspan; c++) {
            tempGrid[currentRowIndexInGrid + r][gridColIndex + c] = cellText;
          }
        }
        gridColIndex += colspan;
      });
      data.push(rowData.map(cell => cell || ''));
    });
  });
  
  if (data.length > 0) {
    const maxCols = Math.max(0, ...data.map(r => r.length));
    return data.map(r => {
        const fullRow = [...r];
        while (fullRow.length < maxCols) fullRow.push('');
        return fullRow;
    });
  }
  return data;
}

// 函数：从用户选择的HTML内容中提取表格数据
function parseSelectionToTableData() {
  const selection = window.getSelection();
  if (!selection || selection.rangeCount === 0) {
    return null;
  }

  const range = selection.getRangeAt(0);
  const container = document.createElement('div');
  container.appendChild(range.cloneContents());

  const tables = Array.from(container.querySelectorAll('table'));
  if (tables.length === 0) {
    let commonAncestor = range.commonAncestorContainer;
    while(commonAncestor && commonAncestor.nodeName !== 'TABLE') {
        commonAncestor = commonAncestor.parentNode;
    }
    if (commonAncestor && commonAncestor.nodeName === 'TABLE') {
        // 如果选区在一个表格内，但没有包含完整的<table>标签，则尝试获取整个表格
        // 需要从原始文档中获取这个表格，而不是range.cloneContents()中的片段
        const originalTable = Array.from(document.querySelectorAll('table')).find(t => t.contains(range.startContainer) && t.contains(range.endContainer));
        if (originalTable) tables.push(originalTable);
    }
  }
  
  if (tables.length === 0) {
      return null;
  }

  const tableToProcess = tables.sort((a,b) => b.querySelectorAll('tr').length - a.querySelectorAll('tr').length)[0] || tables[0];
  return processTableToCSVData(tableToProcess);
}

// 函数：检测并提取页面上最合适的可见表格数据
function detectAndExtractVisibleTableData() {
  const allTables = Array.from(document.querySelectorAll('table'));
  const visibleTables = allTables.filter(table => {
    const style = window.getComputedStyle(table);
    const rect = table.getBoundingClientRect();
    return style.display !== 'none' && 
           style.visibility !== 'hidden' && 
           rect.width > 0 && 
           rect.height > 0 &&
           (table.rows && table.rows.length > 0); // 确保表格有行
  });

  if (visibleTables.length === 0) {
    return null;
  }

  visibleTables.sort((a, b) => {
    const aRows = a.rows.length;
    const bRows = b.rows.length;
    const aCells = a.rows[0] ? a.rows[0].cells.length : 0;
    const bCells = b.rows[0] ? b.rows[0].cells.length : 0;
    // 优先选择面积更大（行数 * 列数）的表格，然后是行数多的
    const aArea = aRows * aCells;
    const bArea = bRows * bCells;
    if (bArea !== aArea) return bArea - aArea;
    return bRows - aRows;
  });

  const bestTable = visibleTables[0];
  return processTableToCSVData(bestTable);
}

// 函数：收集页面上所有表单的数据
function collectAllFormData() {
  const forms = document.querySelectorAll('form');
  if (forms.length === 0) {
    return null;
  }

  const allFormData = [['Form ID/Name', 'Element Name', 'Element Type', 'Value']];
  let formCount = 0;
  let dataAdded = false;

  forms.forEach(form => {
    formCount++;
    const formIdentifier = form.id || form.name || `form_${formCount}`;
    const elements = form.elements;
    for (let i = 0; i < elements.length; i++) {
      const element = elements[i];
      if (!element.name && element.type !== 'submit' && element.type !== 'button' && element.type !== 'reset' && element.type !== 'image') continue; 

      let value = '';
      const type = element.type ? element.type.toLowerCase() : (element.tagName ? element.tagName.toLowerCase() : 'unknown');
      const name = element.name || `unnamed_${type}_${i}`;

      switch (type) {
        case 'text':
        case 'textarea':
        case 'password':
        case 'hidden':
        case 'email':
        case 'number':
        case 'search':
        case 'tel':
        case 'url':
        case 'date':
        case 'datetime-local':
        case 'month':
        case 'week':
        case 'time':
        case 'color':
          value = element.value;
          break;
        case 'select-one':
          value = element.value;
          break;
        case 'select-multiple':
          value = Array.from(element.selectedOptions).map(opt => opt.value).join('; ');
          break;
        case 'checkbox':
        case 'radio':
          if (element.checked) {
            value = element.value;
          } else {
            // 对于未选中的复选框/单选按钮，可以根据需求决定是否记录
            // value = '[unchecked]'; // 或空字符串，或跳过
            continue; 
          }
          break;
        case 'file':
          value = element.files && element.files.length > 0 ? Array.from(element.files).map(f => f.name).join('; ') : '[no file selected]';
          break;
        case 'button':
        case 'submit':
        case 'reset':
        case 'image':
            // 通常这些元素的值不是我们关心的表单数据，但可以记录它们的name或text
            value = element.value || getTextFromElement(element) || `[${type}_button]`;
            break;
        default:
          console.log(`Unhandled form element type: ${type} with name ${name}`);
          value = element.value !== undefined ? element.value : '[unknown_value]';
          break;
      }
      allFormData.push([formIdentifier, name, type, value]);
      dataAdded = true;
    }
  });

  return dataAdded ? allFormData : null;
}

// 监听来自 background.js 的消息
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  console.log("Message received in content script:", request);
  if (request.action === "getSelectedTableData") {
    const tableData = parseSelectionToTableData();
    if (tableData && tableData.length > 0) {
      const csv = arrayToCSV(tableData);
      sendResponse({ csvData: csv, filenamePrefix: "selected_table" });
    } else {
      console.log("No table in selection, trying to detect visible table...");
      const visibleTableData = detectAndExtractVisibleTableData();
      if (visibleTableData && visibleTableData.length > 0) {
        const csv = arrayToCSV(visibleTableData);
        sendResponse({ csvData: csv, filenamePrefix: "auto_detected_table", notice: "未在选区找到表格，已尝试导出页面上最显著的表格。" });
      } else {
        sendResponse({ error: "无法从选区或页面自动检测到可导出的表格数据。" });
      }
    }
  } else if (request.action === "getVisibleTableData") {
    const tableData = detectAndExtractVisibleTableData();
    if (tableData && tableData.length > 0) {
      const csv = arrayToCSV(tableData);
      sendResponse({ csvData: csv, filenamePrefix: "visible_page_table" });
    } else {
      sendResponse({ error: "未能在页面上找到合适的可见表格数据。" });
    }
  } else if (request.action === "getAllFormData") {
    const formData = collectAllFormData();
    if (formData && formData.length > 0) {
      const csv = arrayToCSV(formData);
      sendResponse({ csvData: csv, filenamePrefix: "all_forms_data" });
    } else {
      sendResponse({ error: "未能在页面上找到任何表单数据。" });
    }
  }
  return true; // 异步发送响应
});

// (可选) 监听mouseup事件以捕获用户选择，用于可能的即时反馈或未来功能
// 当前的右键菜单逻辑不直接依赖这个，但可以保留用于其他交互
/*
document.addEventListener('mouseup', () => {
  const selection = window.getSelection();
  if (selection && !selection.isCollapsed && selection.rangeCount > 0) {
    // 用户有选择文本，可以考虑在这里做一些预处理或高亮
    // 例如，可以尝试解析选中的内容是否为表格，并存储起来
    // console.log("Selection captured for potential export.");
  }
});
*/