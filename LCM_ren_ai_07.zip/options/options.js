document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('settingsForm');
  const autoSaveCheckbox = document.getElementById('autoSave');
  const fileNameTemplateInput = document.getElementById('fileNameTemplate');
  const excludeHiddenFormFieldsCheckbox = document.getElementById('excludeHiddenFormFields');
  const statusMessageDiv = document.getElementById('statusMessage');

  const defaultSettings = {
    autoSave: false,
    fileNameTemplate: '[filenamePrefix]_[timestamp].csv',
    excludeHiddenFormFields: true
  };

  function showStatusMessage(message, isError = false) {
    statusMessageDiv.textContent = message;
    statusMessageDiv.className = 'status-message ' + (isError ? 'error' : 'success');
    statusMessageDiv.style.display = 'block';
    setTimeout(() => {
        statusMessageDiv.style.display = 'none';
    }, 3000);
  }
  
  // 加载保存的设置
  chrome.storage.sync.get(['settings'], (result) => {
    const loadedSettings = { ...defaultSettings, ...(result.settings || {}) };
    autoSaveCheckbox.checked = loadedSettings.autoSave;
    fileNameTemplateInput.value = loadedSettings.fileNameTemplate;
    excludeHiddenFormFieldsCheckbox.checked = loadedSettings.excludeHiddenFormFields;
  });

  // 保存设置
  form.addEventListener('submit', (e) => {
    e.preventDefault();
    
    const currentSettings = {
      autoSave: autoSaveCheckbox.checked,
      fileNameTemplate: fileNameTemplateInput.value || defaultSettings.fileNameTemplate, // 如果为空，则使用默认值
      excludeHiddenFormFields: excludeHiddenFormFieldsCheckbox.checked
    };

    chrome.storage.sync.set({ settings: currentSettings }, () => {
      if (chrome.runtime.lastError) {
        console.error("Error saving settings:", chrome.runtime.lastError.message);
        showStatusMessage(`保存设置失败: ${chrome.runtime.lastError.message}`, true);
      } else {
        showStatusMessage('设置已保存！');
      }
    });
  });
});