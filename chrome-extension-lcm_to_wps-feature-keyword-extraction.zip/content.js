// 内容脚本 - 用于与页面交互
(function() {
  'use strict';
  
  'use strict';

  const TABLE_SELECTOR_ATTR = 'data-table-extractor-target';
  let highlightedTable = null; // Keep track of the currently highlighted table

  // 监听右键点击事件
  document.addEventListener('contextmenu', function(e) {
    const element = document.elementFromPoint(e.clientX, e.clientY);
    const table = element ? element.closest('table') : null;

    // Clear previous attribute from any table
    const previouslyMarkedTable = document.querySelector(`[${TABLE_SELECTOR_ATTR}="true"]`);
    if (previouslyMarkedTable) {
      previouslyMarkedTable.removeAttribute(TABLE_SELECTOR_ATTR);
      if (highlightedTable === previouslyMarkedTable) { // only remove old highlight if it's the one we are clearing attr from
          removeHighlight(highlightedTable);
      }
    }
    
    if (highlightedTable && highlightedTable !== table) { // If a different table was highlighted, clear its highlight
        removeHighlight(highlightedTable);
        highlightedTable = null;
    }

    if (table) {
      table.setAttribute(TABLE_SELECTOR_ATTR, 'true');
      highlightTable(table);
      highlightedTable = table; // Store the currently highlighted table
      
      // Optional: remove highlight after a delay, but keep the attribute until extraction
      setTimeout(() => {
        if (table.getAttribute(TABLE_SELECTOR_ATTR) === 'true') { // Only remove highlight if it's still the target
             // We won't remove highlight here anymore, background will tell us when to clear or it clears attribute itself
        }
      }, 3500); // Slightly longer than before, just for visual cue
    }
  }, true); // Use capture phase to ensure this runs before other context menu listeners if any

  // 高亮表格 (Highlight table)
  function highlightTable(table) {
    if(table) {
      table.style.outline = '3px solid #007cba';
      table.style.backgroundColor = 'rgba(0, 124, 186, 0.1)';
    }
  }
  
  // 移除高亮 (Remove highlight)
  function removeHighlight(table) {
    if(table) {
      table.style.outline = '';
      table.style.backgroundColor = '';
    }
  }
  
  // 监听来自background script的消息 (Listen for messages from background script)
  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    let responseData = {};
    if (request.action === 'getRightClickedTableInfo') {
      const targetTableElement = document.querySelector(`[${TABLE_SELECTOR_ATTR}="true"]`);
      if (targetTableElement) {
        sendResponse({ success: true, tableFound: true, selector: `[${TABLE_SELECTOR_ATTR}="true"]` });
      } else {
        sendResponse({ success: true, tableFound: false });
      }
      return true;
    } else if (request.action === 'clearTableHighlightAndAttribute') {
        const targetTableElement = document.querySelector(`[${TABLE_SELECTOR_ATTR}="true"]`);
        if (targetTableElement) {
            removeHighlight(targetTableElement);
            targetTableElement.removeAttribute(TABLE_SELECTOR_ATTR);
            highlightedTable = null; 
            sendResponse({ success: true, cleared: true });
        } else {
            sendResponse({ success: false, cleared: false, message: "No target table found to clear." });
        }
        return true;
    } else if (request.action === 'getSelectedText') {
      const selectedText = window.getSelection().toString().trim();
      sendResponse({ selectedText: selectedText });
      return true;
    } else if (request.action === "extractTextByKeywords" || request.action === "extractFullText") {
        // This is the new handler for the new context menu items
        let extractedText = "";
        if (request.action === "extractTextByKeywords") {
            // request.keywords will come from background.js, which gets them from storage
            if (request.keywords && request.keywords.length > 0) {
                extractedText = extractTextUsingKeywords(document.body.innerText, request.keywords);
                responseData.source = 'keywords';
            } else {
                extractedText = "Error: No keywords provided for extraction by content script.";
            }
        } else { // extractFullText
            extractedText = document.body.innerText;
            responseData.source = 'fullText';
        }
        responseData.text = extractedText;
        // request.pdfKeywords and request.pdfRegex will come from background.js
        responseData.pdfLinks = findPdfLinksOnPage(request.pdfKeywords, request.pdfRegex);
        
        // Send extracted content and PDF links back to background.js
        chrome.runtime.sendMessage({ action: "contentExtracted", ...responseData });
        sendResponse({ success: true, message: "Content extraction processing in content script." });
        return true; // Indicate async response if sendMessage itself is async, or if other logic here is.
    }
    // Fallback or handling for older/other actions if necessary
    // console.log("Message received in content.js: ", request.action);
    return true; // Keep the message channel open for sendResponse
  });

// Renamed and refined function for extracting text based on keywords
function extractTextUsingKeywords(text, keywords) {
    let result = "";
    if (!keywords || keywords.length === 0) return "No keywords provided.";

    // This logic attempts to find text between pairs of keywords or sentences containing keywords.
    // It can be quite complex to get right for all cases.
    // A simpler approach for "Extract to CSV by Keywords" might be to find all occurrences of each keyword
    // and return the surrounding sentence or paragraph for each.
    // For now, let's try a slightly refined version of the previous logic:
    
    // Attempt 1: Find text between consecutive keywords if they are meant to be pairs
    // This assumes keywords are like ["Start1", "End1", "Start2", "End2"]
    // If keywords are just a list like ["TopicA", "TopicB"], this logic might not be what's intended.
    // Let's assume for now keywords are individual terms to find sentences for.

    const sentences = text.match(/[^.!?]+[.!?]+/g) || []; // Split text into sentences
    const foundTexts = [];

    keywords.forEach(kw => {
        const keywordRegex = new RegExp(escapeRegExp(kw), 'gi');
        sentences.forEach(sentence => {
            if (keywordRegex.test(sentence)) {
                if (!foundTexts.includes(sentence.trim())) { // Avoid duplicate sentences
                    foundTexts.push(sentence.trim());
                }
            }
        });
    });

    if (foundTexts.length > 0) {
        result = foundTexts.join('\n\n'); // Join found sentences with double newline
    } else {
        result = "No text found containing the specified keywords.";
    }
    return result;
}

// Renamed and refined function for finding PDF links
function findPdfLinksOnPage(keywords, regexPattern) {
    const links = [];
    const aTags = document.getElementsByTagName('a');
    let regex = null;

    if (regexPattern) {
        try {
            regex = new RegExp(regexPattern, 'i');
        } catch (e) {
            console.error("Invalid PDF regex pattern in content.js: ", e);
        }
    }

    for (let i = 0; i < aTags.length; i++) {
        const href = aTags[i].href ? new URL(aTags[i].href, document.baseURI).href : null;
        const linkText = (aTags[i].innerText || aTags[i].textContent || "").trim();

        if (!href) continue; // Skip if no href

        // Priority 1: Ends with .pdf
        if (href.toLowerCase().endsWith('.pdf')) {
            if (!links.includes(href)) links.push(href);
            continue; 
        }

        // Priority 2: Matches regex (if provided)
        if (regex) {
            if (regex.test(href) || (linkText && regex.test(linkText))) {
                if (!links.includes(href)) links.push(href);
                continue;
            }
        }

        // Priority 3: Matches keywords (if provided)
        if (keywords && keywords.length > 0) {
            for (const keyword of keywords) {
                if (keyword) { // Ensure keyword is not empty
                    const keywordLower = keyword.toLowerCase();
                    if (href.toLowerCase().includes(keywordLower) || (linkText && linkText.toLowerCase().includes(keywordLower))) {
                        if (!links.includes(href)) links.push(href);
                        break; // Found with this keyword, move to next <a> tag
                    }
                }
            }
        }
    }
    return [...new Set(links)]; // Return unique links
}

// Helper function to escape string for regex
function escapeRegExp(string) {
    if (typeof string !== 'string') return '';
    return string.replace(/[.*+\-?^{}()|[\]\\]/g, '\\$&');
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  let responseData = {};
  if (request.action === 'getRightClickedTableInfo') {
    const targetTableElement = document.querySelector(`[${TABLE_SELECTOR_ATTR}="true"]`);
    if (targetTableElement) {
      sendResponse({ success: true, tableFound: true, selector: `[${TABLE_SELECTOR_ATTR}="true"]` });
    } else {
      sendResponse({ success: true, tableFound: false });
    }
    return true;
  } else if (request.action === 'clearTableHighlightAndAttribute') {
      const targetTableElement = document.querySelector(`[${TABLE_SELECTOR_ATTR}="true"]`);
      if (targetTableElement) {
          removeHighlight(targetTableElement);
          targetTableElement.removeAttribute(TABLE_SELECTOR_ATTR);
          highlightedTable = null; 
          sendResponse({ success: true, cleared: true });
      } else {
          sendResponse({ success: false, cleared: false, message: "No target table found to clear." });
      }
      return true;
  } else if (request.action === 'getSelectedText') {
    const selectedText = window.getSelection().toString().trim();
    sendResponse({ selectedText: selectedText });
    return true;
  } else if (request.action === "extractTextByKeywords" || request.action === "extractFullText") {
      // This is the new handler for the new context menu items
      let extractedText = "";
      if (request.action === "extractTextByKeywords") {
          // request.keywords will come from background.js, which gets them from storage
          if (request.keywords && request.keywords.length > 0) {
              extractedText = extractTextUsingKeywords(document.body.innerText, request.keywords);
              responseData.source = 'keywords';
          } else {
              extractedText = "Error: No keywords provided for extraction by content script.";
          }
      } else { // extractFullText
          extractedText = document.body.innerText;
          responseData.source = 'fullText';
      }
      responseData.text = extractedText;
      // request.pdfKeywords and request.pdfRegex will come from background.js
      responseData.pdfLinks = findPdfLinksOnPage(request.pdfKeywords, request.pdfRegex);
      
      // Send extracted content and PDF links back to background.js
      chrome.runtime.sendMessage({ action: "contentExtracted", ...responseData });
      sendResponse({ success: true, message: "Content extraction processing in content script." });
      return true; // Indicate async response if sendMessage itself is async, or if other logic here is.
  }
  // Fallback or handling for older/other actions if necessary
  // console.log("Message received in content.js: ", request.action);
  return true; // Keep the message channel open for sendResponse
});

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "extractTextByKeywords") {
    // This part will be reused and adapted for the new context menu item
    // It needs to be modified to also find PDF links
    extractAndSendText(true, sendResponse); // true for keyword-based
  } else if (request.action === "extractAllText") {
    // This part will be reused and adapted for the new context menu item
    // It needs to be modified to also find PDF links
    extractAndSendText(false, sendResponse); // false for all text
  } else if (request.action === "extractByKeywordsAndDownloadPdfs") {
    const text = getTextFromPage(true); // true for keyword-based extraction
    const pdfLinks = findPdfLinks();
    sendResponse({ text: text, pdfLinks: pdfLinks });
  } else if (request.action === "copyFullTextAndDownloadPdfs") {
    const text = getTextFromPage(false); // false for full text
    const pdfLinks = findPdfLinks();
    sendResponse({ text: text, pdfLinks: pdfLinks });
  }
  return true; // Keep the message channel open for sendResponse
});

function getTextFromPage(useKeywords) {
  let textContent = '';
  if (useKeywords) {
    // Logic to get keywords from storage and filter text
    // This will be similar to the existing keyword extraction logic in popup.js or options.js
    // For now, let's assume a placeholder function getKeywords()
    const keywords = []; // Placeholder: load keywords from storage
    const allText = document.body.innerText;
    if (keywords && keywords.length > 0) {
        const regex = new RegExp(keywords.join('|'), 'gi');
        const matches = allText.match(regex);
        textContent = matches ? matches.join('\n') : '';
    } else {
        textContent = allText; // Fallback to all text if no keywords
    }
  } else {
    textContent = document.body.innerText;
  }
  return textContent;
}

function findPdfLinks() {
  const links = Array.from(document.querySelectorAll('a[href]'))
    .map(a => a.href)
    .filter(href => href.toLowerCase().endsWith('.pdf'));
  // You might want to add more sophisticated PDF link detection here,
  // e.g., checking MIME types if possible, or looking for specific URL patterns
  // For now, we'll stick to '.pdf' extension.
  // Also, ensure links are absolute
  return links.map(link => new URL(link, document.baseURI).href);
}

// Function to extract text based on keywords (similar to what might be in popup.js/options.js)
// This is a simplified version for demonstration
async function extractAndSendText(useKeywords, sendResponse) {
    let extractedText = "";
    if (useKeywords) {
        const result = await chrome.storage.local.get(['keywords']);
        const keywords = result.keywords || [];
        if (keywords.length > 0) {
            const allText = document.body.innerText;
            // Simple keyword matching, can be improved with regex for whole words, case insensitivity etc.
            const uniqueKeywords = [...new Set(keywords.map(k => k.toLowerCase()))];
            const regex = new RegExp(uniqueKeywords.join('|'), 'gi');
            const matches = allText.match(regex);
            extractedText = matches ? matches.join('\n') : 'No keywords found on page.';
        } else {
            extractedText = 'No keywords configured to extract.';
        }
    } else {
        extractedText = document.body.innerText;
    }
    const pdfLinks = findPdfLinks();
    sendResponse({ text: extractedText, pdfLinks: pdfLinks });
}


// Helper function to escape string for regex
function escapeRegExp(string) {
    if (typeof string !== 'string') return '';
    return string.replace(/[.*+\-?^{}()|[\]\\]/g, '\\$&');
}
return true; // Keep the message channel open for sendResponse
});
}