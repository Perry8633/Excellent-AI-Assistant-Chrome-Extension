// 侧边栏翻译功能实现

// 历史记录数组
let translationHistory = [];

// 监听来自content script的选中文本消息
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'translateSelectionInPanel') {
    const sourceContent = document.getElementById('sourceContent');
    if (sourceContent) {
      sourceContent.value = request.text;
      // 自动触发翻译
      const translateBtn = document.getElementById('translateBtn');
      if (translateBtn) {
         translateBtn.click();
      }
    }
  }
  sendResponse({});
  return true;
});

// 初始化页面
document.addEventListener('DOMContentLoaded', () => {
  // 获取DOM元素
  const sourceContent = document.getElementById('sourceContent');
  const targetLang = document.getElementById('targetLang');
  const translateBtn = document.getElementById('translateBtn');
  const translatedResult = document.querySelector('#translatedContent .result');
  const loadingIndicator = document.querySelector('#translatedContent .loading');
  const historyList = document.getElementById('historyList');
  const clearHistoryBtn = document.getElementById('clearHistory');
  
  // 加载目标语言选项
  const languages = [
    { code: 'zh', name: '中文' },
    { code: 'en', name: '英文' },
    { code: 'ja', name: '日文' },
    { code: 'ko', name: '韩文' },
    { code: 'fr', name: '法文' },
    { code: 'de', name: '德文' },
    { code: 'es', name: '西班牙文' },
    { code: 'ru', name: '俄文' }
  ];
  
  languages.forEach(lang => {
    const option = document.createElement('option');
    option.value = lang.code;
    option.textContent = lang.name;
    targetLang.appendChild(option);
  });
  
  // 从存储中加载历史记录
  chrome.storage.local.get(['translationHistory'], (result) => {
    if (result.translationHistory) {
      translationHistory = result.translationHistory;
      renderHistory();
    }
  });
  
  // 翻译按钮点击事件
  translateBtn.addEventListener('click', async () => {
    const sourceText = sourceContent.value.trim();
    const selectedLang = targetLang.value;
  
    if (!sourceText) {
      translatedResult.textContent = '请输入要翻译的文本。'; // 提示用户输入
      return;
    }
  
    // 显示加载指示器
    loadingIndicator.style.display = 'block';
    translatedResult.textContent = '';
    translatedResult.classList.remove('error-message'); // 移除之前的错误样式
  
    try {
      // 获取当前标签页ID
      // 使用 chrome.tabs.query 获取当前活动标签页
      const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
      const tabId = tabs[0]?.id;
  
      if (!tabId) {
        throw new Error("无法获取当前标签页信息");
      }
  
      // 发送翻译请求
      chrome.runtime.sendMessage({
        action: 'translate',
        text: sourceText,
        targetLang: selectedLang,
        tabId: tabId // 传递 tabId
      }, (response) => {
        // 确保在回调执行时 loadingIndicator 仍然存在
        if (!loadingIndicator) return;
        loadingIndicator.style.display = 'none';
  
        // 检查 response 是否有效
        if (chrome.runtime.lastError) {
            console.error('消息发送失败:', chrome.runtime.lastError.message);
            translatedResult.textContent = `通信错误: ${chrome.runtime.lastError.message}`;
            translatedResult.classList.add('error-message');
            return;
        }
  
        if (response && response.error) {
          // 显示详细的错误信息
          console.error('翻译错误:', response.error);
          let errorMessage = `错误: ${response.error}`;
  
          // 针对特定错误提供更友好的提示
          if (response.error.includes('API信息')) {
            errorMessage = `<strong>配置错误:</strong> ${response.error}。<br>请前往<a href="#" id="openOptions">设置页面</a>检查您的API密钥、模型和接口地址。`;
          } else if (response.error.includes('401')) {
            errorMessage = `<strong>认证失败 (401):</strong> API密钥无效或错误。<br>请前往<a href="#" id="openOptions">设置页面</a>检查您的API密钥。`;
          } else if (response.error.includes('402')) {
            errorMessage = `<strong>付款要求 (402):</strong> 您的API密钥可能已超出限额或需要付款。<br>请检查您的API账户状态或前往<a href="#" id="openOptions">设置页面</a>更换密钥。`;
          } else if (response.error.includes('429')) {
            errorMessage = `<strong>请求过多 (429):</strong> 您发送的请求过于频繁，请稍后再试。`;
          } else if (response.error.includes('网络连接错误')) {
            errorMessage = `<strong>网络错误:</strong> 无法连接到API服务器。<br>请检查您的网络连接或<a href="#" id="openOptions">设置页面</a>中的API接口地址。`;
          } else if (response.error.includes('格式异常')) {
            errorMessage = `<strong>API响应错误:</strong> 收到的数据格式不正确，请稍后重试或检查API设置。`;
          }
  
          translatedResult.innerHTML = errorMessage;
          translatedResult.classList.add('error-message'); // 添加错误样式
  
          // 添加设置页面链接点击事件 (如果链接存在)
          document.getElementById('openOptions')?.addEventListener('click', (e) => {
            e.preventDefault(); // 阻止默认链接行为
            chrome.runtime.openOptionsPage();
          });
  
        } else if (response && response.translation) {
          translatedResult.textContent = response.translation;
          translatedResult.classList.remove('error-message'); // 移除错误样式
  
          // 添加到历史记录
          addToHistory(sourceText, response.translation, selectedLang);
        } else {
          // 未知响应或空响应
          console.error('收到无效的翻译响应:', response);
          translatedResult.textContent = '收到无效的响应，请重试。';
          translatedResult.classList.add('error-message');
        }
      });
    } catch (error) {
      // 处理 sendMessage 之前的错误，例如获取 tabId 失败
      console.error('翻译请求准备阶段出错:', error);
      if (loadingIndicator) loadingIndicator.style.display = 'none';
      translatedResult.textContent = `发生错误: ${error.message}`;
      translatedResult.classList.add('error-message');
    }
  });
  
  // 添加到历史记录
  function addToHistory(source, translation, lang) {
    const historyItem = {
      source,
      translation,
      lang,
      timestamp: Date.now()
    };
    
    // 添加到数组开头
    translationHistory.unshift(historyItem);
    
    // 限制历史记录数量
    if (translationHistory.length > 20) {
      translationHistory.pop();
    }
    
    // 保存到存储
    chrome.storage.local.set({ translationHistory });
    
    // 更新UI
    renderHistory();
  }
  
  // 渲染历史记录
  function renderHistory() {
    historyList.innerHTML = '';
    
    translationHistory.forEach((item, index) => {
      const historyItem = document.createElement('div');
      historyItem.className = 'history-item';
      
      const sourcePreview = item.source.length > 30 ? 
        item.source.substring(0, 30) + '...' : item.source;
      
      historyItem.innerHTML = `
        <div class="history-content">
          <div class="history-source">${sourcePreview}</div>
          <div class="history-time">${new Date(item.timestamp).toLocaleString()}</div>
        </div>
      `;
      
      historyItem.addEventListener('click', () => {
        sourceContent.value = item.source;
        targetLang.value = item.lang;
        translatedResult.textContent = item.translation;
      });
      
      historyList.appendChild(historyItem);
    });
  }
  
  // 清除历史记录
  clearHistoryBtn.addEventListener('click', () => {
    translationHistory = [];
    chrome.storage.local.remove('translationHistory');
    renderHistory();
  });
});