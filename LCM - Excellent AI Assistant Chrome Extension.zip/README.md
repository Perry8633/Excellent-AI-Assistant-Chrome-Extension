AI Assistant Chrome Extension

#### 概述
「智语星澜 AI 助手 Chrome 扩展」融合前沿 AI 技术，构建一站式智能服务平台。无论是即时精准的网页翻译，高效智能的 AI 搜索，还是创新的截图识别搜索，亦或是强大的 PDF、txt 文件关键字提取与检索，皆可轻松实现。侧边栏界面设计精巧，用户得以随心处理网页内容、快速选取文本，同时便捷管理历史操作记录，畅享智慧冲浪新体验。
This "WisdomSpeak AI Assistant Chrome Extension" integrates cutting-edge AI technology to build an all-in-one intelligent service platform. Whether it's instant and accurate web page translation, efficient and intelligent AI search, innovative screenshot recognition search, or powerful keyword extraction and retrieval from PDF and txt files, all these functions can be easily achieved. With an exquisitely designed sidebar interface, users can freely handle web page content, quickly select text, and conveniently manage historical operation records, enjoying a new experience of intelligent surfing.

#### 功能特性
- **灵犀互译**：网页内容实时翻译，交互流畅自然，打破语言隔阂。
- **记忆留痕**：自动存档翻译历史，随时回溯查阅，知识积累触手可及。
- **智联万象**：支持自定义 API 端点，灵活适配多元需求，拓展功能边界。
- **Spiritual Translation**: Real-time translation of web page content with smooth and natural interaction, breaking down language barriers.
- **Memory Trace**: Automatically archive translation history, allowing for easy review at any time, and making knowledge accumulation within reach.
- **Intelligent Connection**: Supports custom API endpoints, flexibly adapting to diverse needs and expanding functional boundaries.

#### 安装说明
1. 下载最新版本扩展包；
2. 打开 Chrome 浏览器，访问`chrome://extensions/`；
3. 启用开发者模式；
4. 将下载的扩展包拖入页面，完成安装。
Installation Instructions
1. Download the latest version of the extension package;
2. Open the Chrome browser and visit `chrome://extensions/`;
3. Enable developer mode;
4. Drag the downloaded extension package into the page to complete the installation.

#### 使用指南
1. 轻点浏览器工具栏扩展图标，开启侧边栏智能面板；
2. 在输入框输入或粘贴内容；
3. 依需求选择对应功能模块；
4. 点击操作按钮，静候智能结果呈现；
5. 右键选中网页文本，一键唤醒 AI 功能，即刻获取专业解析。
Usage Guide
1. Tap the extension icon in the browser toolbar to open the intelligent sidebar panel;
2. Enter or paste content into the input box;
3. Select the corresponding functional module according to your needs;
4. Click the operation button and wait for the intelligent results to appear;
5. Right-click to select the web page text, wake up the AI function with one click, and instantly obtain professional analysis.

#### 配置选项
1. 打开扩展设置页面；
2. 精准配置 API 密钥与端点，定制专属智能服务通道；
Configuration Options
1. Open the extension settings page;
2. Precisely configure the API key and endpoints to customize your exclusive intelligent service channel; 