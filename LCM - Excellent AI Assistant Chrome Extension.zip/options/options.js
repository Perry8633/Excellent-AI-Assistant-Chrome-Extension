document.addEventListener('DOMContentLoaded', () => {
  // 加载保存的设置
  chrome.storage.sync.get(
    {
      apiEndpoint: '`https://api.deepseek.com/chat/completions',
      apiKey: 'your_api_key_here',
      model: 'deepseek-chat'
    },
    (items) => {
      document.getElementById('apiEndpoint').value = items.apiEndpoint;
      document.getElementById('apiKey').value = items.apiKey;
      document.getElementById('model').value = items.model;
    }
  );

  // 保存设置
  document.getElementById('save').addEventListener('click', () => {
    const apiEndpoint = document.getElementById('apiEndpoint').value;
    const apiKey = document.getElementById('apiKey').value;
    const model = document.getElementById('model').value;

    chrome.storage.sync.set(
      {
        apiEndpoint,
        apiKey,
        model
      },
      () => {
        const status = document.getElementById('status');
        status.textContent = '设置已保存';
        status.style.color = 'green';
        setTimeout(() => {
          status.textContent = '';
        }, 2000);
      }
    );
  });
}); 