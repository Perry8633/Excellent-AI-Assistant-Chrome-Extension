// 获取特定标签页的设置 (保持不变)
const getTabSettings = async (tabId) => {
  return new Promise((resolve) => {
    chrome.storage.local.get(
      {
        [`targetLang_${tabId}`]: 'zh'  // 获取特定标签页的目标语言
      },
      async (tabItems) => {
        // 获取全局API设置
        const globalSettings = await chrome.storage.sync.get({
          apiEndpoint: 'https://api.deepseek.com/chat/completions',  // 默认使用DeepSeek API
          apiKey: 'apiKey',
          model: 'deepseek-chat'  // 默认使用deepseek-chat模型
        });

        resolve({
          ...globalSettings,
          targetLang: tabItems[`targetLang_${tabId}`]
        });
      }
    );
  });
};

// 调用API进行翻译 (增强错误处理)
const translateWithAPI = async (text, targetLang, apiKey, model, apiEndpoint) => {
  // 新增API地址清洗逻辑
  const cleanedEndpoint = apiEndpoint.replace(/[\s`]/g, ''); // 移除空格和反引号
  try {
    new URL(cleanedEndpoint);
  } catch (error) {
    throw new Error(`API地址格式无效: ${cleanedEndpoint}`);
  }

  // 新增API密钥验证
  if (!apiKey || !/^[a-zA-Z0-9-]{32,64}$/.test(apiKey.trim())) {
    throw new Error('API密钥格式错误：应为32-64位字母数字组合');
  }

  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), 15000);

  try {
    const response = await fetch(cleanedEndpoint, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${apiKey.trim()}`
      },
      body: JSON.stringify({
        model: "deepseek-chat", // 固定模型名称
        messages: [
          {
            role: "system",
            content: `你是一个翻译助手。请将用户输入的文本翻译成${targetLang}，只返回翻译结果，不需要解释。`
          },
          {
            role: "user",
            content: text
          }
        ],
        temperature: 0.3
      })
    });

    if (!response.ok) {
      const errorText = await response.text().catch(() => '无法获取错误详情');
      console.error(`API请求失败: 状态码 ${response.status}, 错误信息: ${errorText}`);
      
      // 针对特定状态码提供更明确的错误信息
      if (response.status === 402) {
        throw new Error('翻译请求失败: 付款要求 (402)。您的API密钥可能已超出使用限额或需要付款。请检查您的API账户状态。');
      } else if (response.status === 401) {
        throw new Error('翻译请求失败: 认证失败 (401)。请检查您的API密钥是否正确。');
      } else if (response.status === 429) {
        throw new Error('翻译请求失败: 请求过多 (429)。请稍后再试。');
      } else {
        throw new Error(`翻译请求失败: 状态码 ${response.status}。${errorText ? `错误详情: ${errorText}` : ''}`);
      }
    }

    const data = await response.json();
    
    if (!data.choices || !data.choices[0] || !data.choices[0].message) {
      console.error('API返回数据格式异常:', data);
      throw new Error('API返回数据格式异常');
    }
    
    return data.choices[0].message.content.trim();
  } catch (error) {
    clearTimeout(timeoutId);
    console.error('翻译过程中发生错误:', error);
    
    // 增强错误分类处理
    if (error.name === 'AbortError') {
      throw new Error(`请求超时: 无法在15秒内连接到API服务器 (${apiEndpoint})`);
    }
    
    if (error.message.includes('Failed to fetch')) {
      throw new Error(`网络连接异常，请检查：
1. 本地网络是否正常
2. API地址是否可访问 (当前: ${apiEndpoint})
3. 是否配置了有效的API密钥`);
    }
    
    throw error; // 抛出其他未处理的错误
  }
};

// 监听来自 content script 或 side panel 的消息
// 注意：此处的消息监听器已移至下方，避免重复
// 使用 sidePanel API
chrome.action.onClicked.addListener((tab) => {
  chrome.sidePanel.open({ windowId: tab.windowId });
});

// 创建右键菜单项
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: "open-ai-translator-sidepanel",
    title: "AI极简翻译助手",
    contexts: ["page", "selection"] // 可以在页面空白处或选中文本时显示
  });
});

// 监听右键菜单点击事件
chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId === "open-ai-translator-sidepanel" && tab) {
    // 打开侧边栏
    chrome.sidePanel.open({ windowId: tab.windowId });

    // 如果有选中的文本，可以发送消息给 sidepanel
    if (info.selectionText) {
      // 等待 sidepanel 加载完成可能需要延迟或更复杂的通信
      setTimeout(() => {
        chrome.runtime.sendMessage({
          action: 'translateSelectionInPanel',
          text: info.selectionText
        }).catch(error => {
          // 捕获错误，例如 sidepanel 还未准备好接收消息
          console.log("无法发送消息到 sidepanel:", error);
          // 可以考虑重试或其他错误处理逻辑
        });
      }, 500); // 简单的延迟，可能需要更可靠的方法
    }
  }
});

// 监听插件图标点击事件，打开或关闭侧边栏
chrome.action.onClicked.addListener(async (tab) => {
  if (tab.id) {
    await chrome.sidePanel.open({ tabId: tab.id });
  }
});

// 监听来自 content script 或 popup/sidepanel 的消息
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'translate') {
    (async () => {
      try {
        // 统一使用 getTabSettings 获取设置，不再区分 isPopupWindow
        // 注意：如果 sidepanel 需要不同的目标语言逻辑，这里可能需要调整
        // 假设 sidepanel 也是基于当前 tab 的设置
        const tabId = request.tabId || sender.tab?.id;
        if (!tabId) {
            throw new Error("无法确定标签页ID");
        }

        const settings = await getTabSettings(tabId);
        // 如果请求中明确指定了 targetLang (例如来自 sidepanel 的手动选择)，则使用它
        const finalTargetLang = request.targetLang || settings.targetLang;

        const translation = await translateWithAPI(
          request.text,
          finalTargetLang, // 使用最终确定的目标语言
          settings.apiKey,
          settings.model,
          settings.apiEndpoint
        );
        sendResponse({ translation });
      } catch (error) {
        console.error("翻译错误:", error); // 添加日志方便调试
        sendResponse({ error: error.message });
      }
    })();
    return true; // 表示异步响应
  } else if (request.action === 'getCurrentTabId') {
    // 处理来自 content script 的请求
    if (sender.tab) {
      sendResponse({ tabId: sender.tab.id });
    } else {
      // 如果发送者不是 content script (例如 popup 或 options)
      // 需要查询当前活动标签页
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        if (tabs.length > 0) {
          sendResponse({ tabId: tabs[0].id });
        } else {
          sendResponse({ tabId: null });
        }
      });
      return true; // 异步响应
    }
  } else if (request.action === 'updateSourceLanguage') {
    // 可以在这里处理源语言更新，例如更新图标或状态
    console.log(`Tab ${request.tabId} source language updated to: ${request.language}`);
    // 如果需要，可以将语言信息存储起来或发送给其他部分
    sendResponse({}); // 确认收到消息
  }
  // 可以添加其他消息处理逻辑
});

// 移除 panelStates 变量
// let panelStates = {};

// 修改 action 点击事件，使用 sidePanel API
chrome.action.onClicked.addListener((tab) => {
  chrome.sidePanel.open({ windowId: tab.windowId });
});

// 确保在 service worker 启动时设置侧边栏行为
chrome.sidePanel
  .setPanelBehavior({ openPanelOnActionClick: true })
  .catch((error) => console.error(error));

// chrome.windows.onRemoved.addListener((windowId) => { ... });

// 辅助函数：翻译文本
async function translateText(text, targetLang, tabId) {
  try {
    // 获取API设置
    const settings = await getTabSettings(tabId);
    
    // 使用提供的目标语言或默认语言
    const finalTargetLang = targetLang || settings.targetLang;
    
    // 调用API进行翻译
    const translation = await translateWithAPI(
      text,
      finalTargetLang,
      settings.apiKey,
      settings.model,
      settings.apiEndpoint
    );
    
    return { translation };
  } catch (error) {
    console.error("翻译错误:", error);
    return { error: error.message };
  }
}

