chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "exportData") {
    // Chain the promises: get scan keywords, then form fields, then extract values
    chrome.storage.sync.get('scanKeywords').then(keywordConfig => {
        getFormFields().then(fields => {
            const data = extractFormValues(fields, keywordConfig.scanKeywords);
            sendResponse({data});
        }).catch(error => {
            sendResponse({error: error.message});
            console.error("Error getting form fields:", error);
        });
    }).catch(error => {
        sendResponse({error: error.message});
        console.error("Error getting scan keywords:", error);
    });
    return true; // Keep message channel open for async response
  }
  
  // 修改处理getSelectedTableData消息的逻辑
  if (request.action === "getSelectedTableData") {
    console.log("收到getSelectedTableData请求，当前选中数据：", selectedTableDataForExport);
    
    // 检查是否有有效的表格数据
    if (selectedTableDataForExport && Array.isArray(selectedTableDataForExport) && selectedTableDataForExport.length > 0) {
      // 验证数据格式：确保是二维数组
      const isValidTableData = selectedTableDataForExport.every(row => Array.isArray(row));
      
      if (isValidTableData) {
        console.log("发送有效的表格数据到background.js", selectedTableDataForExport);
        // 发送选中的表格数据到background.js进行CSV导出
        chrome.runtime.sendMessage({
          action: "saveCSV",
          data: selectedTableDataForExport
        }, response => {
          if (chrome.runtime.lastError) {
            console.error("发送表格数据失败:", chrome.runtime.lastError);
            sendResponse({error: chrome.runtime.lastError.message});
          } else {
            console.log("表格数据已发送到background.js进行CSV导出", response);
            sendResponse({status: "success"});
          }
        });
      } else {
        console.error("选中的数据格式不正确，不是二维数组:", selectedTableDataForExport);
        sendResponse({error: "选中的数据格式不正确"});
      }
    } else {
      console.log("没有选中有效的表格数据，尝试智能检测页面表格");
      
      // 如果没有选中数据，尝试智能检测页面中的表格
      const detectedTableData = detectAndExtractTableData();
      if (detectedTableData && detectedTableData.length > 0) {
        console.log("检测到页面表格数据:", detectedTableData);
        chrome.runtime.sendMessage({
          action: "saveCSV",
          data: detectedTableData
        }, response => {
          if (chrome.runtime.lastError) {
            console.error("发送检测到的表格数据失败:", chrome.runtime.lastError);
            sendResponse({error: chrome.runtime.lastError.message});
          } else {
            console.log("检测到的表格数据已发送到background.js进行CSV导出", response);
            sendResponse({status: "success"});
          }
        });
      } else {
        sendResponse({status: "no_selection", message: "未找到可导出的表格数据"});
      }
    }
    return true; // 保持消息通道开放以进行异步响应
  }
});

async function getFormFields() {
  // 优先使用用户自定义字段配置
  const config = await chrome.storage.sync.get('formFields');
  if (config.formFields && config.formFields.length > 0) {
    return config.formFields;
  }

  // fallback to default fields
  return [
    {name: "名称", selectors: ["[id*='name']", "[name*='title']", "[id*='company-name']", "[name*='company-name']"]},
    {name: "类型", selectors: ["[id*='type']", "[name*='type']", "[id*='category']", "[name*='category']"]},
    {name: "受限制主体编号", selectors: ["[id*='number']", "[name*='code']", "[id*='entity-id']", "[name*='entity-id']", "[id*='company-code']"]},
    {name: "国家/地区", selectors: ["[id*='country']", "[name*='region']", "[name*='country_region']"]},
    {name: "城市", selectors: ["[id*='city']", "[name*='city']"]},
    {name: "详细地址", selectors: ["[id*='address']", "[name*='addr']", "[id*='street']"]},
    {name: "邮编", selectors: ["[id*='postcode']", "[name*='zip']", "[id*='postal_code']"]},
    {name: "备注", selectors: ["[id*='remark']", "[name*='note']", "textarea[name*='comment']", "textarea[id*='comment']"]}
    // "扫描主体名称" is added dynamically in extractFormValues
  ];
}

function extractFormValues(fields, scanKeywords) {
  const data = {};
  fields.forEach(field => {
    const element = findFormElement(field.selectors, field.name);
    data[field.name] = element ? getElementValue(element).trim() : ""; 
  });

  // Extract "扫描主体名称" using keywords
  let scannedName = "";
  if (scanKeywords && scanKeywords.start && scanKeywords.end) {
    const pageText = document.body.innerText;
    const startIndex = pageText.indexOf(scanKeywords.start);
    const endIndex = pageText.indexOf(scanKeywords.end);

    if (startIndex !== -1 && endIndex !== -1 && endIndex > startIndex) {
      // Extract text between the end of startKeyword and the beginning of endKeyword
      scannedName = pageText.substring(startIndex + scanKeywords.start.length, endIndex).trim();
    }
  }
  data["扫描主体名称"] = scannedName;

  return data;
}

// 新增：智能检测页面表格数据的函数
function detectAndExtractTableData() {
  console.log("开始智能检测页面表格...");
  
  // 查找页面中的所有可见的 table 元素
  const tables = Array.from(document.querySelectorAll('table')).filter(table => {
    // 检查表格是否可见
    const style = window.getComputedStyle(table);
    const isVisible = style.display !== 'none' && style.visibility !== 'hidden' && table.offsetParent !== null;
    if (!isVisible) {
      console.log("表格不可见，已跳过：", table);
    }
    return isVisible;
  });
  
  console.log(`找到 ${tables.length} 个可见的表格`);
  
  if (tables.length === 0) {
    console.log("未找到可见的 <table> 元素，尝试检测类似表格的结构");
    return detectTableLikeStructures(); // 保留对类表格结构的处理作为后备
  }
  
  // 评估表格质量并选择最佳表格
  let bestTable = null;
  let highestScore = -1;
  
  tables.forEach(table => {
    let score = 0;
    const hasThead = table.querySelector('thead') !== null;
    const hasTbody = table.querySelector('tbody') !== null;
    const headerCells = table.querySelectorAll('th').length;
    const dataCells = table.querySelectorAll('td').length;
    const firstRowIsHeader = Array.from(table.rows[0]?.cells || []).every(cell => cell.tagName === 'TH');
  
    if (hasThead) score += 3;
    if (hasTbody) score += 2;
    if (headerCells > 0) score += 2;
    if (dataCells > 0) score += 1; // 至少有一些数据单元格
    if (firstRowIsHeader && headerCells > 0) score +=1; // 如果第一行是TH且有TH单元格
  
    // 优先选择结构更完整、内容更丰富的表格
    // 结构完整性优先，其次是单元格数量
    const currentTableScore = score * 1000 + headerCells + dataCells; 
  
    console.log("评估表格:", table, "得分:", currentTableScore, "详细评分:", {hasThead, hasTbody, headerCells, dataCells, firstRowIsHeader});
  
    if (currentTableScore > highestScore) {
      highestScore = currentTableScore;
      bestTable = table;
    }
  });
  
  if (bestTable) {
    console.log("选择的最佳表格:", bestTable, "最高分:", highestScore);
    return extractTableData(bestTable);
  }
  
  console.log("没有找到合适的 <table> 元素进行提取。");
  return [];
}

// 新增：检测类似表格的结构（如div布局的表格）
function detectTableLikeStructures() {
  console.log("检测类似表格的结构...");
  
  // 查找具有表格特征的元素
  const potentialTables = document.querySelectorAll(
    '[class*="table"], [class*="grid"], [class*="data"], [role="table"], [role="grid"]'
  );
  
  for (const element of potentialTables) {
    const rows = element.querySelectorAll(
      '[role="row"], tr, [class*="row"], .table-row'
    );
    
    if (rows.length > 1) { // 至少有2行数据
      console.log("找到类似表格的结构", element);
      return extractTableLikeData(element, rows);
    }
  }
  
  return [];
}

// 新增：从标准表格提取数据
function extractTableData(table) {
  const tableData = [];
  let headerData = [];

  // 尝试从 thead 获取表头
  const thead = table.querySelector('thead');
  if (thead && thead.rows.length > 0) {
    headerData = Array.from(thead.rows[0].cells).map(cell => cell.innerText.trim());
  } else {
    // 如果没有 thead 或者 thead 为空，尝试将表格的第一行作为表头（如果包含 th）
    if (table.rows.length > 0) {
      const firstRowCells = Array.from(table.rows[0].cells);
      if (firstRowCells.some(cell => cell.tagName === 'TH')) {
        headerData = firstRowCells.map(cell => cell.innerText.trim());
      } else if (firstRowCells.length > 0 && !tableData.length) {
        // 如果第一行没有TH，但作为一种备选，如果它是唯一的行或者还没有数据，也可能作为表头
        // 这种情况比较模糊，但为了兼容性可以考虑，或者更严格地要求必须有TH
        // 为了更准确，我们这里要求表头行至少包含一个TH，或者整个表格只有一行时，该行作为数据行
      }
    }
  }

  if (headerData.length > 0) {
    // 过滤掉完全由空字符串组成的表头行
    if (headerData.some(headerText => headerText !== '')) {
        tableData.push(headerData);
        console.log("提取的表头数据:", headerData);
    } else {
        console.log("检测到表头行，但所有单元格均为空，已忽略该表头行。");
        headerData = []; // 重置，避免影响后续数据行判断
    }
  }

  // 提取表格数据行 (tbody 或者所有行)
  const dataRowsSource = table.querySelector('tbody') ? table.querySelector('tbody').rows : table.rows;
  const rows = Array.from(dataRowsSource);

  rows.forEach((row, rowIndex) => {
    // 如果表头是从第一行提取的，并且已经加入了tableData，则跳过第一行数据
    if (headerData.length > 0 && table.rows[0] === row && tableData.length > 0 && tableData[0] === headerData) {
        console.log("跳过已作为表头处理的第一行数据");
        return; 
    }
    // 如果没有thead，但第一行被识别为表头，则数据从第二行开始
    // 这种情况已通过上面的判断处理：如果headerData有内容，且当前行是table.rows[0]，且tableData已有内容（即表头），则跳过

    const cells = Array.from(row.cells);
    const rowData = cells.map(cell => cell.innerText.trim());
    
    // 只添加非空行 (至少有一个单元格有内容)
    if (rowData.some(cellText => cellText !== '')) {
      tableData.push(rowData);
    }
  });

  console.log("最终提取的表格数据 (包含表头，如果有):", tableData);
  return tableData;
}

// 新增：从类似表格的结构提取数据
function extractTableLikeData(container, rows) {
  const tableData = [];
  
  rows.forEach(row => {
    const cells = row.querySelectorAll(
      '[role="cell"], [role="gridcell"], td, th, [class*="cell"], .table-cell'
    );
    
    if (cells.length > 0) {
      const rowData = Array.from(cells).map(cell => cell.innerText.trim());
      if (rowData.some(cell => cell !== '')) { // 只添加非空行
        tableData.push(rowData);
      }
    }
  });
  
  console.log("提取的类似表格数据:", tableData);
  return tableData;
}

// 改进的表格选择检测
let selectedTableDataForExport = [];

document.addEventListener('mouseup', (event) => {
  const selection = window.getSelection();
  if (!selection || selection.rangeCount === 0 || selection.isCollapsed) {
    selectedTableDataForExport = [];
    return;
  }

  console.log("检测到文本选择，开始分析...");
  const range = selection.getRangeAt(0);
  let commonAncestor = range.commonAncestorContainer;

  // 查找表格元素
  let tableElement = commonAncestor;
  while (tableElement && tableElement.nodeType !== Node.ELEMENT_NODE) {
    tableElement = tableElement.parentNode;
  }
  
  while (tableElement && tableElement.nodeName !== 'TABLE') {
    tableElement = tableElement.parentNode;
  }

  if (!tableElement) {
    console.log("未在标准表格中检测到选择，尝试检测其他表格结构");
    // 尝试检测其他类型的表格结构
    selectedTableDataForExport = detectSelectionInTableLikeStructure(selection, range);
    return;
  }

  console.log("在表格中检测到选择", tableElement);
  const rows = Array.from(tableElement.rows);
  const tempSelectedData = [];

  for (const row of rows) {
    const cellsInRow = Array.from(row.cells);
    const selectedCellsInRow = [];
    
    for (const cell of cellsInRow) {
      if (selection.containsNode(cell, true) || range.intersectsNode(cell)) {
        selectedCellsInRow.push(cell.innerText.trim());
      }
    }
    
    if (selectedCellsInRow.length > 0) {
      tempSelectedData.push(selectedCellsInRow);
    }
  }
  
  if (tempSelectedData.length > 0) {
    // 标准化行长度
    let maxCols = Math.max(...tempSelectedData.map(row => row.length));
    selectedTableDataForExport = tempSelectedData.map(row => {
      const newRow = [...row];
      while (newRow.length < maxCols) {
        newRow.push("");
      }
      return newRow;
    });
    console.log("提取的选中表格数据:", selectedTableDataForExport);
  } else {
    selectedTableDataForExport = [];
  }
});

// 新增：在类似表格结构中检测选择
function detectSelectionInTableLikeStructure(selection, range) {
  console.log("在类似表格结构中检测选择...");
  
  // 查找包含选择的容器
  let container = range.commonAncestorContainer;
  while (container && container.nodeType !== Node.ELEMENT_NODE) {
    container = container.parentNode;
  }
  
  // 向上查找可能的表格容器
  while (container && !container.matches('[class*="table"], [class*="grid"], [class*="data"], [role="table"], [role="grid"]')) {
    container = container.parentNode;
    if (container === document.body) break;
  }
  
  if (!container || container === document.body) {
    console.log("未找到表格容器");
    return [];
  }
  
  console.log("找到表格容器", container);
  
  // 查找行元素
  const rows = container.querySelectorAll(
    '[role="row"], tr, [class*="row"], .table-row'
  );
  
  const tempSelectedData = [];
  
  rows.forEach(row => {
    const cells = row.querySelectorAll(
      '[role="cell"], [role="gridcell"], td, th, [class*="cell"], .table-cell'
    );
    
    const selectedCellsInRow = [];
    
    cells.forEach(cell => {
      if (selection.containsNode(cell, true) || range.intersectsNode(cell)) {
        selectedCellsInRow.push(cell.innerText.trim());
      }
    });
    
    if (selectedCellsInRow.length > 0) {
      tempSelectedData.push(selectedCellsInRow);
    }
  });
  
  if (tempSelectedData.length > 0) {
    let maxCols = Math.max(...tempSelectedData.map(row => row.length));
    const result = tempSelectedData.map(row => {
      const newRow = [...row];
      while (newRow.length < maxCols) {
        newRow.push("");
      }
      return newRow;
    });
    console.log("从类似表格结构提取的选中数据:", result);
    return result;
  }
  
  return [];
}

// findFormElement and getElementValue functions remain the same as in your provided utils.js or previous content.js
// Make sure they are available in this scope.
// If utils.js is imported via manifest.json, they should be.