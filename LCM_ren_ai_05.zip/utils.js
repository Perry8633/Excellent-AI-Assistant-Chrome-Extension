// 查找表单元素的智能算法
function findFormElement(selectors, fieldName) {
  // 1. 尝试通过label关联查找
  const labels = Array.from(document.querySelectorAll("label"));
  const label = labels.find(el => el.textContent.includes(fieldName));
  if (label && label.htmlFor) {
    const element = document.getElementById(label.htmlFor);
    if (element) return element;
  }

  // 2. 尝试通过选择器查找
  for (const selector of selectors) {
    const elements = document.querySelectorAll(selector);
    if (elements.length > 0) {
      // 启发式排序：优先选择有label关联、id/name匹配度高的元素
      return sortElements(elements, fieldName)[0];
    }
  }

  // 3. 尝试通过语义化标签查找
  if (fieldName.includes("地址")) {
    return document.querySelector("[id*='address']") || 
           document.querySelector("[name*='address']");
  }
  return null;
}

// 元素排序算法
function sortElements(elements, fieldName) {
  return Array.from(elements).sort((a, b) => {
    const scoreA = getElementScore(a, fieldName);
    const scoreB = getElementScore(b, fieldName);
    return scoreB - scoreA; // 降序排列
  });
}

// 元素匹配度评分
function getElementScore(element, fieldName) {
  let score = 0;
  const id = element.id || "";
  const name = element.name || "";
  const placeholder = element.placeholder || "";
  const type = element.type || "";
  
  // 匹配字段名称
  if (id.includes(fieldName)) score += 30;
  if (name.includes(fieldName)) score += 20;
  if (placeholder.includes(fieldName)) score += 15;
  
  // 类型相关性
  if (type === "text" || type === "textarea") score += 10;
  if (type === "hidden" && (id.includes("id") || name.includes("id"))) score += 5;
  
  // label关联评分
  const label = document.querySelector(`label[for="${id}"]`);
  if (label && label.textContent.includes(fieldName)) score += 25;
  
  return score;
}

// 获取元素值的通用方法
function getElementValue(element) {
  if (element.tagName === "SELECT") {
    return element.options[element.selectedIndex].text;
  } else if (element.tagName === "TEXTAREA") {
    return element.value;
  } else if (element.type === "checkbox") {
    return element.checked ? "是" : "否";
  } else if (element.type === "radio" && element.checked) {
    const label = document.querySelector(`label[for="${element.id}"]`);
    return label ? label.textContent.trim() : element.value;
  } else {
    return element.value;
  }
}