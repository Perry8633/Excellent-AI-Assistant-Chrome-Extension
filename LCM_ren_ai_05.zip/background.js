chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  switch(request.action) {
    case "saveCSV":
      saveAsCSV(request.data)
        .then(result => sendResponse(result))
        .catch(error => sendResponse({status: "error", message: error.message}));
      return true;
      
    case "getConfig":
      chrome.storage.sync.get('formFields', config => {
        sendResponse({config: config.formFields || []});
      });
      return true;
      
    case "saveConfig":
      chrome.storage.sync.set({formFields: request.config}, () => {
        sendResponse({status: "success"});
      });
      return true;
  }
});

async function saveAsCSV(tableDataArray, filenamePrefix = "表格数据") {
  // 生成CSV内容
  if (!Array.isArray(tableDataArray) || !tableDataArray.every(row => Array.isArray(row))) {
    console.error("saveAsCSV 错误: 输入数据必须是二维数组", tableDataArray);
    throw new Error("导出数据格式错误，需要二维数组。");
  }
  if (tableDataArray.length === 0) {
     console.warn("saveAsCSV 警告: 输入的表格数据为空数组。");
     return {status: "warning", message: "无数据可导出"};
  }

  let csvContent = ""; 
  tableDataArray.forEach(rowArray => {
    const rowString = rowArray.map(cellData => {
      const cellString = String(cellData === null || cellData === undefined ? "" : cellData);
      return `"${cellString.replace(/"/g, '""').replace(/\n/g, '\\n')}"`;
    }).join(",");
    csvContent += rowString + "\n";
  });

  const fileName = `${filenamePrefix}_${new Date().toISOString().slice(0, 19).replace(/:/g, "-")}.csv`;
  
  try {
    const blob = new Blob([csvContent], {type: 'text/csv;charset=utf-8;'});
    const url = URL.createObjectURL(blob);

    const downloadId = await chrome.downloads.download({
      url: url,
      filename: fileName,
      saveAs: true 
    });
    return {status: "success", downloadId};
  } catch (error) {
    console.error("CSV 下载失败: ", error);
    throw new Error("下载失败，不支持的浏览器或权限问题。");
  }
}

// 创建右键菜单项
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: "exportTableAsCSV",
    title: "导出选中表格为CSV",
    contexts: ["selection"] // 仅在有选中文本时显示
  });
  console.log("右键菜单 '导出选中表格为CSV' 已创建。");
});

// 监听右键菜单点击事件
chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId === "exportTableAsCSV" && tab && tab.id) {
    // 向内容脚本发送消息，请求提取选中的表格数据
    chrome.tabs.sendMessage(tab.id, { action: "getSelectedTableData" }, (response) => {
      if (chrome.runtime.lastError) {
        console.error("发送消息到内容脚本失败: ", chrome.runtime.lastError.message);
      } else if (response && response.error) {
        console.error("内容脚本提取数据错误: ", response.error);
      } else if (response && response.status === "no_selection") {
        console.log("内容脚本提示：没有有效的表格选择。");
      }
    });
  }
});